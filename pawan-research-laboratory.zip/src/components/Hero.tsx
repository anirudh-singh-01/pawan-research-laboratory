import React from 'react';
import { Phone, Calendar, MessageCircle, Home, MapPin, CheckCircle2, Clock, ShieldCheck, Tag } from 'lucide-react';
import { Language } from '../types';
import { TRANSLATIONS } from '../data/translations';

interface HeroProps {
  language: Language;
  onOpenBooking: () => void;
  onNavigateToHomeCollection: () => void;
}

export const Hero: React.FC<HeroProps> = ({
  language,
  onOpenBooking,
  onNavigateToHomeCollection,
}) => {
  const t = TRANSLATIONS[language];

  const whatsappMessage = encodeURIComponent(
    `Hello Pawan Research Laboratory, I would like to inquire about pathology test booking and sample collection in Kanpur.`
  );
  const whatsappUrl = `https://wa.me/919335736360?text=${whatsappMessage}`;

  return (
    <section id="home" className="relative bg-gradient-to-b from-teal-50/60 via-slate-50 to-white pt-8 pb-16 lg:pt-12 lg:pb-20 border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Main 2-Column Split */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 items-center">
          
          {/* Left Column: Proposition & CTAs (7 cols) */}
          <div className="lg:col-span-7 space-y-6">
            
            {/* Unboxed Section Label */}
            <div className="flex items-center gap-2 text-xs font-semibold tracking-wider text-teal-800 uppercase">
              <span className="w-6 h-0.5 bg-teal-700"></span>
              <span>{t.heroBadge}</span>
              <span aria-hidden="true" className="text-slate-300">·</span>
              <span className="text-slate-500 font-normal normal-case">{t.locationShort}</span>
            </div>

            {/* Main Headline - Dark navy/black bold serif typography */}
            <div className="space-y-2">
              <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-slate-950 font-serif tracking-tight leading-[1.15]" style={{ textWrap: 'balance' }}>
                {language === 'en'
                  ? 'Pawan Research Laboratory'
                  : 'पवन रिसर्च लैबोरेटरी'}
              </h1>
              <p className="text-xl sm:text-2xl font-bold text-teal-900/90 font-serif italic">
                "{t.tagline}"
              </p>
            </div>

            {/* Value Description */}
            <p className="text-base sm:text-lg text-slate-600 leading-relaxed max-w-2xl">
              {t.heroSubheading}
            </p>

            {/* Location Line */}
            <div className="flex items-start gap-2.5 text-xs sm:text-sm text-slate-600 bg-white p-3.5 rounded-xl border border-slate-200/80 shadow-xs max-w-xl">
              <MapPin className="w-5 h-5 text-teal-700 shrink-0 mt-0.5" />
              <div>
                <span className="font-semibold text-slate-900">
                  {language === 'en' ? 'Laboratory Location:' : 'प्रयोगशाला का पता:'}
                </span>{' '}
                <span>{t.locationFull}</span>
              </div>
            </div>

            {/* Primary Action Buttons (Original layout & colors) */}
            <div className="pt-2 flex flex-wrap items-center gap-3">
              {/* 1. Book a Test */}
              <button
                onClick={onOpenBooking}
                className="inline-flex items-center justify-center gap-2 px-5 py-3 text-sm font-semibold text-white bg-teal-800 hover:bg-teal-900 active:bg-teal-950 rounded-xl shadow-sm hover:shadow transition-all whitespace-nowrap cursor-pointer"
              >
                <Calendar className="w-4 h-4 text-teal-200" />
                <span>{t.heroActionBook}</span>
              </button>

              {/* 2. Call Now */}
              <a
                href={`tel:${t.phone}`}
                className="inline-flex items-center justify-center gap-2 px-5 py-3 text-sm font-semibold text-slate-800 hover:text-teal-950 bg-white hover:bg-slate-100 border border-slate-300 rounded-xl shadow-xs transition-colors whitespace-nowrap"
              >
                <Phone className="w-4 h-4 text-teal-700" />
                <span>{t.heroActionCall}</span>
              </a>

              {/* 3. WhatsApp */}
              <a
                href={whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center justify-center gap-2 px-4 py-3 text-sm font-semibold text-emerald-900 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 rounded-xl transition-colors whitespace-nowrap"
              >
                <MessageCircle className="w-4 h-4 text-emerald-700" />
                <span>{t.heroActionWhatsApp}</span>
              </a>

              {/* 4. Home Sample Collection */}
              <button
                onClick={onNavigateToHomeCollection}
                className="inline-flex items-center justify-center gap-2 px-4 py-3 text-sm font-semibold text-teal-900 bg-teal-100/70 hover:bg-teal-200/80 border border-teal-200 rounded-xl transition-colors whitespace-nowrap cursor-pointer"
              >
                <Home className="w-4 h-4 text-teal-800" />
                <span>{t.heroActionHome}</span>
              </button>
            </div>

            {/* Trust Markers without pills */}
            <div className="pt-2 flex flex-wrap items-center gap-y-2 gap-x-6 text-xs text-slate-600">
              <span className="flex items-center gap-1.5 font-medium">
                <CheckCircle2 className="w-4 h-4 text-teal-700" />
                {t.heroTrust1}
              </span>
              <span className="flex items-center gap-1.5 font-medium">
                <CheckCircle2 className="w-4 h-4 text-teal-700" />
                {t.heroTrust2}
              </span>
              <span className="flex items-center gap-1.5 font-medium">
                <CheckCircle2 className="w-4 h-4 text-teal-700" />
                {t.heroTrust3}
              </span>
            </div>

          </div>

          {/* Right Column: Newly uploaded laboratory photograph & Dark Teal Pricing Card */}
          <div className="lg:col-span-5 space-y-4">
            
            {/* The Newly Uploaded Laboratory Photograph */}
            <div className="relative rounded-2xl bg-white p-2.5 shadow-lg border border-slate-200 overflow-hidden">
              <div className="relative rounded-xl overflow-hidden bg-slate-100 aspect-[4/3] max-h-[310px]">
                <img
                  src="/assets/aistudio/WhatsApp_Image_2026-10-27_at_7.31.24_PM_12933866.jpeg"
                  alt="Pawan Pal (M.D), Pawan Research Laboratory"
                  className="w-full h-full object-cover object-top"
                  referrerPolicy="no-referrer"
                />
                
                {/* Subtle scrim & verified banner */}
                <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-slate-950/90 via-slate-900/50 to-transparent p-3 text-white flex items-center justify-between">
                  <div>
                    <div className="flex items-center gap-1 text-teal-300 text-xs font-semibold">
                      <ShieldCheck className="w-3.5 h-3.5 text-teal-300" />
                      <span>Verified Reports · Pawan Pal (M.D)</span>
                    </div>
                    <p className="text-xs font-bold text-white mt-0.5">
                      Pawan Research Laboratory
                    </p>
                  </div>
                  <span className="text-[10px] font-mono text-teal-200 bg-teal-900/80 px-2 py-0.5 rounded border border-teal-700">
                    Naubasta · Kanpur
                  </span>
                </div>
              </div>
            </div>

            {/* The Original Dark Teal Test Pricing Card */}
            <div className="relative rounded-2xl bg-gradient-to-br from-teal-900 via-teal-950 to-slate-900 text-white p-5 shadow-xl border border-teal-800/40">
              
              {/* Header inside Graphic Card */}
              <div className="flex items-center justify-between pb-3 border-b border-teal-800/60">
                <div className="flex items-center gap-2">
                  <div className="w-7 h-7 rounded-lg bg-teal-800 flex items-center justify-center">
                    <svg className="w-4 h-4 text-teal-200" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                      <path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/>
                      <polyline points="3.27 6.96 12 12.01 20.73 6.96"/>
                      <line x1="12" y1="22.08" x2="12" y2="12"/>
                    </svg>
                  </div>
                  <div>
                    <p className="text-[10px] font-mono uppercase tracking-wider text-teal-300">
                      Pawan Research Laboratory
                    </p>
                    <p className="text-xs font-semibold text-white">
                      Diagnostic Test Charges (20% OFF MRP)
                    </p>
                  </div>
                </div>
                <span className="text-[10px] font-mono text-emerald-300 bg-emerald-950/80 px-2 py-0.5 rounded border border-emerald-700/60 font-bold">
                  20% OFF
                </span>
              </div>

              {/* Medical Diagnostic Visual Composition */}
              <div className="py-3 my-2 bg-slate-950/40 rounded-xl p-3 border border-teal-800/40">
                <div className="grid grid-cols-3 gap-2 text-center">
                  <div className="p-2.5 bg-teal-900/40 rounded-lg border border-teal-700/30">
                    <div className="text-teal-300 text-[11px] font-medium mb-0.5">
                      {language === 'en' ? 'Routine Tests' : 'रूटीन टेस्ट'}
                    </div>
                    <div className="text-sm sm:text-base font-bold font-mono text-white tabular-nums">CBC · ₹320</div>
                    <div className="text-[10px] text-slate-400 line-through">MRP: ₹400</div>
                  </div>
                  <div className="p-2.5 bg-teal-900/40 rounded-lg border border-teal-700/30">
                    <div className="text-teal-300 text-[11px] font-medium mb-0.5">
                      {language === 'en' ? 'Organ Panels' : 'अंग प्रोफाइल'}
                    </div>
                    <div className="text-sm sm:text-base font-bold font-mono text-white tabular-nums">LFT · ₹520</div>
                    <div className="text-[10px] text-slate-400 line-through">MRP: ₹650</div>
                  </div>
                  <div className="p-2.5 bg-teal-900/40 rounded-lg border border-teal-700/30">
                    <div className="text-teal-300 text-[11px] font-medium mb-0.5">
                      {language === 'en' ? 'Endocrine' : 'हार्मोन जांच'}
                    </div>
                    <div className="text-sm sm:text-base font-bold font-mono text-white tabular-nums">T3/T4/TSH · ₹480</div>
                    <div className="text-[10px] text-slate-400 line-through">MRP: ₹600</div>
                  </div>
                </div>

                {/* SVG Visual: Clean Laboratory Test Tubes & Clock */}
                <div className="mt-3 pt-2.5 border-t border-teal-800/40 flex items-center justify-between text-[11px] text-teal-200">
                  <div className="flex items-center gap-1.5">
                    <div className="w-2 h-2 rounded-full bg-teal-400"></div>
                    <span>Single-use Vacutainer Safety</span>
                  </div>
                  <div className="flex items-center gap-1 font-mono text-teal-300">
                    <Clock className="w-3 h-3 text-teal-400" />
                    <span>07:00 AM – 08:30 PM</span>
                  </div>
                </div>
              </div>

              {/* Direct Booking CTA Card Footnote */}
              <div className="pt-1 flex items-center justify-between">
                <div>
                  <p className="text-[11px] text-teal-300">
                    {language === 'en' ? 'Need a sample collected at home?' : 'घर पर खून जांच करवानी है?'}
                  </p>
                  <p className="text-xs font-semibold text-white">
                    {language === 'en' ? 'Book doorstep collection now' : 'तुरंत होम कलेक्शन बुक करें'}
                  </p>
                </div>
                <button
                  onClick={onNavigateToHomeCollection}
                  className="px-3 py-1.5 text-xs font-semibold bg-teal-600 hover:bg-teal-500 text-white rounded-lg transition-colors cursor-pointer"
                >
                  {language === 'en' ? 'Book Slot' : 'स्लॉट चुनें'}
                </button>
              </div>

            </div>

          </div>

        </div>

        {/* Full-width 4-Column Feature/KPI Strip below the Hero Split */}
        <div className="mt-14 pt-8 border-t border-slate-200 grid grid-cols-2 md:grid-cols-4 gap-6">
          <div className="space-y-1">
            <p className="text-lg sm:text-xl font-bold text-slate-900 tracking-tight font-serif">
              {t.statTests}
            </p>
            <p className="text-xs sm:text-sm text-slate-500">
              {t.statTestsSub}
            </p>
          </div>
          <div className="space-y-1">
            <p className="text-lg sm:text-xl font-bold text-slate-900 tracking-tight font-serif">
              {t.statLocation}
            </p>
            <p className="text-xs sm:text-sm text-slate-500">
              {t.statLocationSub}
            </p>
          </div>
          <div className="space-y-1">
            <p className="text-lg sm:text-xl font-bold text-slate-900 tracking-tight font-serif">
              {t.statReporting}
            </p>
            <p className="text-xs sm:text-sm text-slate-500">
              {t.statReportingSub}
            </p>
          </div>
          <div className="space-y-1">
            <p className="text-lg sm:text-xl font-bold text-slate-900 tracking-tight font-serif">
              {t.statCare}
            </p>
            <p className="text-xs sm:text-sm text-slate-500">
              {t.statCareSub}
            </p>
          </div>
        </div>

      </div>
    </section>
  );
};
