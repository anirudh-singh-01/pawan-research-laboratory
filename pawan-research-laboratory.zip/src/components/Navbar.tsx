import React, { useState } from 'react';
import { Phone, Calendar, Menu, X, Globe, ShieldAlert } from 'lucide-react';
import { Language } from '../types';
import { TRANSLATIONS } from '../data/translations';

interface NavbarProps {
  language: Language;
  onLanguageChange: (lang: Language) => void;
  onOpenBooking: () => void;
  onOpenPrivacy: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  language,
  onLanguageChange,
  onOpenBooking,
  onOpenPrivacy
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const t = TRANSLATIONS[language];

  const handleNavClick = (href: string) => {
    setMobileMenuOpen(false);
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <>
      {/* Top Notification Strip */}
      <div className="bg-teal-950 text-teal-100 px-4 py-1.5 text-xs">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-1">
          <div className="flex items-center gap-2 text-center sm:text-left">
            <span className="font-semibold text-white tracking-wide">{t.tagline}</span>
            <span className="hidden md:inline text-teal-400" aria-hidden="true">·</span>
            <span className="hidden md:inline text-teal-200">{t.locationShort}</span>
            <span className="hidden lg:inline text-teal-400" aria-hidden="true">·</span>
            <span className="hidden lg:inline text-teal-200 font-medium">20% OFF on MRP</span>
          </div>
          <div className="flex items-center gap-4">
            <a
              href={`tel:${t.phone}`}
              className="text-teal-200 hover:text-white transition-colors flex items-center gap-1 font-mono font-medium"
            >
              <Phone className="w-3 h-3 text-teal-400" />
              <span>{t.phone}</span>
            </a>
            <span className="text-teal-600" aria-hidden="true">|</span>
            <button
              onClick={() => onLanguageChange(language === 'en' ? 'hi' : 'en')}
              className="flex items-center gap-1 text-teal-200 hover:text-white font-medium transition-colors cursor-pointer"
              title="Switch Language"
            >
              <Globe className="w-3 h-3 text-teal-400" />
              <span>{language === 'en' ? 'हिंदी' : 'English'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main Navigation Bar - Strictly complies with Top Bar Contract */}
      <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200 shadow-xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-18 flex items-center justify-between gap-8">
          {/* Zone 1: Brand Wordmark (Single clean line with full name) */}
          <a
            href="#home"
            className="flex items-center gap-2.5 text-slate-900 group whitespace-nowrap shrink-0"
          >
            <div className="w-10 h-10 rounded-lg bg-teal-800 text-white flex items-center justify-center font-bold text-lg shadow-sm">
              <svg className="w-6 h-6 text-teal-300" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="m14 2 4 4-2 2-4-4 2-2Z"/>
                <path d="M12 4v4"/>
                <path d="M10 6 8.5 7.5"/>
                <path d="m2 22 7-7"/>
                <path d="m5 19 3 3"/>
                <circle cx="16" cy="18" r="4"/>
              </svg>
            </div>
            <div className="flex flex-col">
              <span className="font-extrabold text-base sm:text-lg tracking-tight text-slate-950 font-serif">
                {language === 'en' ? 'Pawan Research Laboratory' : 'पवन रिसर्च लैबोरेटरी'}
              </span>
              <span className="text-[10px] sm:text-[11px] font-semibold text-teal-700 tracking-wider">
                {language === 'en' ? 'PATHOLOGY & CLINICAL DIAGNOSTICS' : 'पैथोलॉजी एवं क्लिनिकल डायग्नोस्टिक्स'}
              </span>
            </div>
          </a>

          {/* Zone 2: 4-5 Clean Single-Line Nav Links */}
          <nav className="hidden lg:flex items-center gap-6 text-sm font-medium text-slate-700">
            <button
              onClick={() => handleNavClick('#home')}
              className="hover:text-teal-800 transition-colors whitespace-nowrap shrink-0 py-1 cursor-pointer"
            >
              {t.navHome}
            </button>
            <button
              onClick={() => handleNavClick('#about')}
              className="hover:text-teal-800 transition-colors whitespace-nowrap shrink-0 py-1 cursor-pointer"
            >
              {t.navAbout}
            </button>
            <button
              onClick={() => handleNavClick('#tests')}
              className="hover:text-teal-800 transition-colors whitespace-nowrap shrink-0 py-1 cursor-pointer"
            >
              {t.navTests}
            </button>
            <button
              onClick={() => handleNavClick('#packages')}
              className="hover:text-teal-800 transition-colors whitespace-nowrap shrink-0 py-1 cursor-pointer"
            >
              {t.navWellness}
            </button>
            <button
              onClick={() => handleNavClick('#home-collection')}
              className="hover:text-teal-800 transition-colors whitespace-nowrap shrink-0 py-1 cursor-pointer"
            >
              {t.navHomeCollection}
            </button>
            <button
              onClick={() => handleNavClick('#contact')}
              className="hover:text-teal-800 transition-colors whitespace-nowrap shrink-0 py-1 cursor-pointer"
            >
              {t.navContact}
            </button>
          </nav>

          {/* Zone 3: 1 Primary CTA Button + Language Toggle */}
          <div className="flex items-center gap-3 shrink-0">
            <button
              onClick={() => onLanguageChange(language === 'en' ? 'hi' : 'en')}
              className="hidden sm:inline-flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-semibold text-slate-700 hover:text-teal-900 bg-slate-100 hover:bg-slate-200 rounded-md transition-colors cursor-pointer"
            >
              <Globe className="w-3.5 h-3.5 text-teal-700" />
              <span>{language === 'en' ? 'हिंदी' : 'English'}</span>
            </button>

            <button
              onClick={onOpenBooking}
              className="inline-flex items-center gap-2 px-4 py-2.5 text-xs sm:text-sm font-semibold text-white bg-teal-800 hover:bg-teal-900 active:bg-teal-950 rounded-lg shadow-sm hover:shadow transition-all whitespace-nowrap shrink-0 cursor-pointer"
            >
              <Calendar className="w-4 h-4 text-teal-200" />
              <span>{t.bookTestBtn}</span>
            </button>

            {/* Mobile Hamburger Button */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2 text-slate-700 hover:text-slate-900 hover:bg-slate-100 rounded-lg focus:outline-none focus-visible:ring-2 focus-visible:ring-teal-700 cursor-pointer"
              aria-label="Toggle navigation menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Navigation Drawer */}
        {mobileMenuOpen && (
          <div className="lg:hidden bg-white border-b border-slate-200 px-4 pt-3 pb-6 space-y-2 shadow-lg animate-in fade-in duration-200">
            <div className="flex items-center justify-between py-2 border-b border-slate-100">
              <span className="text-xs font-medium text-slate-500">Language / भाषा:</span>
              <button
                onClick={() => onLanguageChange(language === 'en' ? 'hi' : 'en')}
                className="inline-flex items-center gap-1 px-3 py-1 text-xs font-semibold text-teal-800 bg-teal-50 border border-teal-200 rounded-md"
              >
                <Globe className="w-3.5 h-3.5" />
                <span>{language === 'en' ? 'हिंदी में देखें' : 'View in English'}</span>
              </button>
            </div>
            <button
              onClick={() => handleNavClick('#home')}
              className="w-full text-left py-2.5 px-3 text-slate-800 font-medium hover:bg-slate-50 rounded-md text-sm"
            >
              {t.navHome}
            </button>
            <button
              onClick={() => handleNavClick('#about')}
              className="w-full text-left py-2.5 px-3 text-slate-800 font-medium hover:bg-slate-50 rounded-md text-sm"
            >
              {t.navAbout}
            </button>
            <button
              onClick={() => handleNavClick('#tests')}
              className="w-full text-left py-2.5 px-3 text-slate-800 font-medium hover:bg-slate-50 rounded-md text-sm"
            >
              {t.navTests}
            </button>
            <button
              onClick={() => handleNavClick('#packages')}
              className="w-full text-left py-2.5 px-3 text-slate-800 font-medium hover:bg-slate-50 rounded-md text-sm"
            >
              {t.navWellness} & {t.navFitness}
            </button>
            <button
              onClick={() => handleNavClick('#home-collection')}
              className="w-full text-left py-2.5 px-3 text-slate-800 font-medium hover:bg-slate-50 rounded-md text-sm"
            >
              {t.navHomeCollection}
            </button>
            <button
              onClick={() => handleNavClick('#contact')}
              className="w-full text-left py-2.5 px-3 text-slate-800 font-medium hover:bg-slate-50 rounded-md text-sm"
            >
              {t.navContact}
            </button>
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenPrivacy();
              }}
              className="w-full text-left py-2 px-3 text-slate-600 text-xs hover:bg-slate-50 rounded-md flex items-center gap-1.5"
            >
              <ShieldAlert className="w-3.5 h-3.5 text-slate-400" />
              <span>{t.navPrivacy}</span>
            </button>
            <div className="pt-3 flex flex-col gap-2">
              <a
                href={`tel:${t.phone}`}
                className="w-full py-2.5 px-4 bg-slate-100 hover:bg-slate-200 text-slate-800 font-semibold rounded-lg text-center text-sm flex items-center justify-center gap-2"
              >
                <Phone className="w-4 h-4 text-teal-700" />
                <span>{t.callNowBtn}: {t.phone}</span>
              </a>
              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  onOpenBooking();
                }}
                className="w-full py-2.5 px-4 bg-teal-800 hover:bg-teal-900 text-white font-semibold rounded-lg text-center text-sm flex items-center justify-center gap-2 shadow-sm"
              >
                <Calendar className="w-4 h-4" />
                <span>{t.bookTestBtn}</span>
              </button>
            </div>
          </div>
        )}
      </header>
    </>
  );
};
