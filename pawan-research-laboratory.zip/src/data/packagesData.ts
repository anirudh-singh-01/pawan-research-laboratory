import { HealthPackage } from '../types';

export const HEALTH_PACKAGES: HealthPackage[] = [
  {
    "id": "pkg-1",
    "name": "WELLENESS1.2 ESR",
    "nameHi": "WELLENESS1.2 ESR",
    "type": "wellness",
    "targetAudience": "Adults, families, seniors & individuals seeking preventive screening",
    "targetAudienceHi": "वयस्क, वरिष्ठ नागरिक एवं नियमित स्वास्थ्य परीक्षण चाहने वाले",
    "price": "₹1440",
    "isConfirmedPrice": true,
    "testsIncluded": [
      "WELLENESS1.2 ESR"
    ],
    "testsIncludedHi": [
      "WELLENESS1.2 ESR"
    ],
    "description": "Comprehensive diagnostic profile for WELLENESS1.2 ESR conducted with clinical accuracy and 20% discount on standard MRP at Pawan Research Laboratory.",
    "descriptionHi": "पवन रिसर्च लैबोरेटरी में 20% एमआरपी छूट के साथ WELLENESS1.2 ESR का संपूर्ण नैदानिक हेल्थ पैकेज।",
    "sampleRequired": "Blood & Urine specimen as required by protocol",
    "recommendedFor": "Preventive healthcare & periodic screening",
    "mrp": 1800,
    "discountedPrice": 1440,
    "discountPercent": 20
  },
  {
    "id": "pkg-2",
    "name": "Wellness -3",
    "nameHi": "Wellness -3",
    "type": "wellness",
    "targetAudience": "Adults, families, seniors & individuals seeking preventive screening",
    "targetAudienceHi": "वयस्क, वरिष्ठ नागरिक एवं नियमित स्वास्थ्य परीक्षण चाहने वाले",
    "price": "₹2000",
    "isConfirmedPrice": true,
    "testsIncluded": [
      "Wellness -3"
    ],
    "testsIncludedHi": [
      "Wellness -3"
    ],
    "description": "Comprehensive diagnostic profile for Wellness -3 conducted with clinical accuracy and 20% discount on standard MRP at Pawan Research Laboratory.",
    "descriptionHi": "पवन रिसर्च लैबोरेटरी में 20% एमआरपी छूट के साथ Wellness -3 का संपूर्ण नैदानिक हेल्थ पैकेज।",
    "sampleRequired": "Blood & Urine specimen as required by protocol",
    "recommendedFor": "Preventive healthcare & periodic screening",
    "mrp": 2500,
    "discountedPrice": 2000,
    "discountPercent": 20
  },
  {
    "id": "pkg-3",
    "name": "Wellness -2",
    "nameHi": "Wellness -2",
    "type": "wellness",
    "targetAudience": "Adults, families, seniors & individuals seeking preventive screening",
    "targetAudienceHi": "वयस्क, वरिष्ठ नागरिक एवं नियमित स्वास्थ्य परीक्षण चाहने वाले",
    "price": "₹1440",
    "isConfirmedPrice": true,
    "testsIncluded": [
      "Wellness -2"
    ],
    "testsIncludedHi": [
      "Wellness -2"
    ],
    "description": "Comprehensive diagnostic profile for Wellness -2 conducted with clinical accuracy and 20% discount on standard MRP at Pawan Research Laboratory.",
    "descriptionHi": "पवन रिसर्च लैबोरेटरी में 20% एमआरपी छूट के साथ Wellness -2 का संपूर्ण नैदानिक हेल्थ पैकेज।",
    "sampleRequired": "Blood & Urine specimen as required by protocol",
    "recommendedFor": "Preventive healthcare & periodic screening",
    "mrp": 1800,
    "discountedPrice": 1440,
    "discountPercent": 20
  },
  {
    "id": "pkg-4",
    "name": "Wellness -1",
    "nameHi": "Wellness -1",
    "type": "wellness",
    "targetAudience": "Adults, families, seniors & individuals seeking preventive screening",
    "targetAudienceHi": "वयस्क, वरिष्ठ नागरिक एवं नियमित स्वास्थ्य परीक्षण चाहने वाले",
    "price": "₹960",
    "isConfirmedPrice": true,
    "testsIncluded": [
      "Wellness -1"
    ],
    "testsIncludedHi": [
      "Wellness -1"
    ],
    "description": "Comprehensive diagnostic profile for Wellness -1 conducted with clinical accuracy and 20% discount on standard MRP at Pawan Research Laboratory.",
    "descriptionHi": "पवन रिसर्च लैबोरेटरी में 20% एमआरपी छूट के साथ Wellness -1 का संपूर्ण नैदानिक हेल्थ पैकेज।",
    "sampleRequired": "Blood & Urine specimen as required by protocol",
    "recommendedFor": "Preventive healthcare & periodic screening",
    "mrp": 1200,
    "discountedPrice": 960,
    "discountPercent": 20
  },
  {
    "id": "pkg-5",
    "name": "WELLNESS-1.7",
    "nameHi": "WELLNESS-1.7",
    "type": "wellness",
    "targetAudience": "Adults, families, seniors & individuals seeking preventive screening",
    "targetAudienceHi": "वयस्क, वरिष्ठ नागरिक एवं नियमित स्वास्थ्य परीक्षण चाहने वाले",
    "price": "₹6000",
    "isConfirmedPrice": true,
    "testsIncluded": [
      "WELLNESS-1.7"
    ],
    "testsIncludedHi": [
      "WELLNESS-1.7"
    ],
    "description": "Comprehensive diagnostic profile for WELLNESS-1.7 conducted with clinical accuracy and 20% discount on standard MRP at Pawan Research Laboratory.",
    "descriptionHi": "पवन रिसर्च लैबोरेटरी में 20% एमआरपी छूट के साथ WELLNESS-1.7 का संपूर्ण नैदानिक हेल्थ पैकेज।",
    "sampleRequired": "Blood & Urine specimen as required by protocol",
    "recommendedFor": "Preventive healthcare & periodic screening",
    "mrp": 7500,
    "discountedPrice": 6000,
    "discountPercent": 20
  },
  {
    "id": "pkg-6",
    "name": "WELLNESS-1.1+CBC",
    "nameHi": "WELLNESS-1.1+CBC",
    "type": "wellness",
    "targetAudience": "Adults, families, seniors & individuals seeking preventive screening",
    "targetAudienceHi": "वयस्क, वरिष्ठ नागरिक एवं नियमित स्वास्थ्य परीक्षण चाहने वाले",
    "price": "₹800",
    "isConfirmedPrice": true,
    "testsIncluded": [
      "WELLNESS-1.1+CBC"
    ],
    "testsIncludedHi": [
      "WELLNESS-1.1+CBC"
    ],
    "description": "Comprehensive diagnostic profile for WELLNESS-1.1+CBC conducted with clinical accuracy and 20% discount on standard MRP at Pawan Research Laboratory.",
    "descriptionHi": "पवन रिसर्च लैबोरेटरी में 20% एमआरपी छूट के साथ WELLNESS-1.1+CBC का संपूर्ण नैदानिक हेल्थ पैकेज।",
    "sampleRequired": "Blood & Urine specimen as required by protocol",
    "recommendedFor": "Preventive healthcare & periodic screening",
    "mrp": 1000,
    "discountedPrice": 800,
    "discountPercent": 20
  },
  {
    "id": "pkg-7",
    "name": "WELLNESS-1.6",
    "nameHi": "WELLNESS-1.6",
    "type": "wellness",
    "targetAudience": "Adults, families, seniors & individuals seeking preventive screening",
    "targetAudienceHi": "वयस्क, वरिष्ठ नागरिक एवं नियमित स्वास्थ्य परीक्षण चाहने वाले",
    "price": "₹5200",
    "isConfirmedPrice": true,
    "testsIncluded": [
      "WELLNESS-1.6"
    ],
    "testsIncludedHi": [
      "WELLNESS-1.6"
    ],
    "description": "Comprehensive diagnostic profile for WELLNESS-1.6 conducted with clinical accuracy and 20% discount on standard MRP at Pawan Research Laboratory.",
    "descriptionHi": "पवन रिसर्च लैबोरेटरी में 20% एमआरपी छूट के साथ WELLNESS-1.6 का संपूर्ण नैदानिक हेल्थ पैकेज।",
    "sampleRequired": "Blood & Urine specimen as required by protocol",
    "recommendedFor": "Preventive healthcare & periodic screening",
    "mrp": 6500,
    "discountedPrice": 5200,
    "discountPercent": 20
  },
  {
    "id": "pkg-8",
    "name": "WELLNESS-1.5",
    "nameHi": "WELLNESS-1.5",
    "type": "wellness",
    "targetAudience": "Adults, families, seniors & individuals seeking preventive screening",
    "targetAudienceHi": "वयस्क, वरिष्ठ नागरिक एवं नियमित स्वास्थ्य परीक्षण चाहने वाले",
    "price": "₹4640",
    "isConfirmedPrice": true,
    "testsIncluded": [
      "WELLNESS-1.5"
    ],
    "testsIncludedHi": [
      "WELLNESS-1.5"
    ],
    "description": "Comprehensive diagnostic profile for WELLNESS-1.5 conducted with clinical accuracy and 20% discount on standard MRP at Pawan Research Laboratory.",
    "descriptionHi": "पवन रिसर्च लैबोरेटरी में 20% एमआरपी छूट के साथ WELLNESS-1.5 का संपूर्ण नैदानिक हेल्थ पैकेज।",
    "sampleRequired": "Blood & Urine specimen as required by protocol",
    "recommendedFor": "Preventive healthcare & periodic screening",
    "mrp": 5800,
    "discountedPrice": 4640,
    "discountPercent": 20
  },
  {
    "id": "pkg-9",
    "name": "WELLNESS-1.4",
    "nameHi": "WELLNESS-1.4",
    "type": "wellness",
    "targetAudience": "Adults, families, seniors & individuals seeking preventive screening",
    "targetAudienceHi": "वयस्क, वरिष्ठ नागरिक एवं नियमित स्वास्थ्य परीक्षण चाहने वाले",
    "price": "₹3840",
    "isConfirmedPrice": true,
    "testsIncluded": [
      "WELLNESS-1.4"
    ],
    "testsIncludedHi": [
      "WELLNESS-1.4"
    ],
    "description": "Comprehensive diagnostic profile for WELLNESS-1.4 conducted with clinical accuracy and 20% discount on standard MRP at Pawan Research Laboratory.",
    "descriptionHi": "पवन रिसर्च लैबोरेटरी में 20% एमआरपी छूट के साथ WELLNESS-1.4 का संपूर्ण नैदानिक हेल्थ पैकेज।",
    "sampleRequired": "Blood & Urine specimen as required by protocol",
    "recommendedFor": "Preventive healthcare & periodic screening",
    "mrp": 4800,
    "discountedPrice": 3840,
    "discountPercent": 20
  },
  {
    "id": "pkg-10",
    "name": "WELLNESS-1.3",
    "nameHi": "WELLNESS-1.3",
    "type": "wellness",
    "targetAudience": "Adults, families, seniors & individuals seeking preventive screening",
    "targetAudienceHi": "वयस्क, वरिष्ठ नागरिक एवं नियमित स्वास्थ्य परीक्षण चाहने वाले",
    "price": "₹2000",
    "isConfirmedPrice": true,
    "testsIncluded": [
      "WELLNESS-1.3"
    ],
    "testsIncludedHi": [
      "WELLNESS-1.3"
    ],
    "description": "Comprehensive diagnostic profile for WELLNESS-1.3 conducted with clinical accuracy and 20% discount on standard MRP at Pawan Research Laboratory.",
    "descriptionHi": "पवन रिसर्च लैबोरेटरी में 20% एमआरपी छूट के साथ WELLNESS-1.3 का संपूर्ण नैदानिक हेल्थ पैकेज।",
    "sampleRequired": "Blood & Urine specimen as required by protocol",
    "recommendedFor": "Preventive healthcare & periodic screening",
    "mrp": 2500,
    "discountedPrice": 2000,
    "discountPercent": 20
  },
  {
    "id": "pkg-11",
    "name": "WELLNESS-1.2",
    "nameHi": "WELLNESS-1.2",
    "type": "wellness",
    "targetAudience": "Adults, families, seniors & individuals seeking preventive screening",
    "targetAudienceHi": "वयस्क, वरिष्ठ नागरिक एवं नियमित स्वास्थ्य परीक्षण चाहने वाले",
    "price": "₹1280",
    "isConfirmedPrice": true,
    "testsIncluded": [
      "WELLNESS-1.2"
    ],
    "testsIncludedHi": [
      "WELLNESS-1.2"
    ],
    "description": "Comprehensive diagnostic profile for WELLNESS-1.2 conducted with clinical accuracy and 20% discount on standard MRP at Pawan Research Laboratory.",
    "descriptionHi": "पवन रिसर्च लैबोरेटरी में 20% एमआरपी छूट के साथ WELLNESS-1.2 का संपूर्ण नैदानिक हेल्थ पैकेज।",
    "sampleRequired": "Blood & Urine specimen as required by protocol",
    "recommendedFor": "Preventive healthcare & periodic screening",
    "mrp": 1600,
    "discountedPrice": 1280,
    "discountPercent": 20
  },
  {
    "id": "pkg-12",
    "name": "WELLNESS-1.1",
    "nameHi": "WELLNESS-1.1",
    "type": "wellness",
    "targetAudience": "Adults, families, seniors & individuals seeking preventive screening",
    "targetAudienceHi": "वयस्क, वरिष्ठ नागरिक एवं नियमित स्वास्थ्य परीक्षण चाहने वाले",
    "price": "₹800",
    "isConfirmedPrice": true,
    "testsIncluded": [
      "WELLNESS-1.1"
    ],
    "testsIncludedHi": [
      "WELLNESS-1.1"
    ],
    "description": "Comprehensive diagnostic profile for WELLNESS-1.1 conducted with clinical accuracy and 20% discount on standard MRP at Pawan Research Laboratory.",
    "descriptionHi": "पवन रिसर्च लैबोरेटरी में 20% एमआरपी छूट के साथ WELLNESS-1.1 का संपूर्ण नैदानिक हेल्थ पैकेज।",
    "sampleRequired": "Blood & Urine specimen as required by protocol",
    "recommendedFor": "Preventive healthcare & periodic screening",
    "mrp": 1000,
    "discountedPrice": 800,
    "discountPercent": 20
  },
  {
    "id": "pkg-13",
    "name": "HY FITNESS COMPREHENSIVE PROFILE",
    "nameHi": "HY FITNESS COMPREHENSIVE PROFILE",
    "type": "fitness",
    "targetAudience": "Athletes, gym enthusiasts, runners and active individuals",
    "targetAudienceHi": "जिम जाने वाले युवाओं, धावकों और फिटनेस उत्साही व्यक्तियों हेतु",
    "price": "₹960",
    "isConfirmedPrice": true,
    "testsIncluded": [
      "HY FITNESS COMPREHENSIVE PROFILE"
    ],
    "testsIncludedHi": [
      "HY FITNESS COMPREHENSIVE PROFILE"
    ],
    "description": "Comprehensive diagnostic profile for HY FITNESS COMPREHENSIVE PROFILE conducted with clinical accuracy and 20% discount on standard MRP at Pawan Research Laboratory.",
    "descriptionHi": "पवन रिसर्च लैबोरेटरी में 20% एमआरपी छूट के साथ HY FITNESS COMPREHENSIVE PROFILE का संपूर्ण नैदानिक हेल्थ पैकेज।",
    "sampleRequired": "Blood & Urine specimen as required by protocol",
    "recommendedFor": "Preventive healthcare & periodic screening",
    "mrp": 1200,
    "discountedPrice": 960,
    "discountPercent": 20
  },
  {
    "id": "pkg-14",
    "name": "HY FITNESS-1.3 PRO",
    "nameHi": "HY FITNESS-1.3 PRO",
    "type": "fitness",
    "targetAudience": "Athletes, gym enthusiasts, runners and active individuals",
    "targetAudienceHi": "जिम जाने वाले युवाओं, धावकों और फिटनेस उत्साही व्यक्तियों हेतु",
    "price": "₹2800",
    "isConfirmedPrice": true,
    "testsIncluded": [
      "HY FITNESS-1.3 PRO"
    ],
    "testsIncludedHi": [
      "HY FITNESS-1.3 PRO"
    ],
    "description": "Comprehensive diagnostic profile for HY FITNESS-1.3 PRO conducted with clinical accuracy and 20% discount on standard MRP at Pawan Research Laboratory.",
    "descriptionHi": "पवन रिसर्च लैबोरेटरी में 20% एमआरपी छूट के साथ HY FITNESS-1.3 PRO का संपूर्ण नैदानिक हेल्थ पैकेज।",
    "sampleRequired": "Blood & Urine specimen as required by protocol",
    "recommendedFor": "Preventive healthcare & periodic screening",
    "mrp": 3500,
    "discountedPrice": 2800,
    "discountPercent": 20
  },
  {
    "id": "pkg-15",
    "name": "HY FITNESS-B",
    "nameHi": "HY FITNESS-B",
    "type": "fitness",
    "targetAudience": "Athletes, gym enthusiasts, runners and active individuals",
    "targetAudienceHi": "जिम जाने वाले युवाओं, धावकों और फिटनेस उत्साही व्यक्तियों हेतु",
    "price": "₹320",
    "isConfirmedPrice": true,
    "testsIncluded": [
      "HY FITNESS-B"
    ],
    "testsIncludedHi": [
      "HY FITNESS-B"
    ],
    "description": "Comprehensive diagnostic profile for HY FITNESS-B conducted with clinical accuracy and 20% discount on standard MRP at Pawan Research Laboratory.",
    "descriptionHi": "पवन रिसर्च लैबोरेटरी में 20% एमआरपी छूट के साथ HY FITNESS-B का संपूर्ण नैदानिक हेल्थ पैकेज।",
    "sampleRequired": "Blood & Urine specimen as required by protocol",
    "recommendedFor": "Preventive healthcare & periodic screening",
    "mrp": 400,
    "discountedPrice": 320,
    "discountPercent": 20
  },
  {
    "id": "pkg-16",
    "name": "HY FITNESS-A",
    "nameHi": "HY FITNESS-A",
    "type": "fitness",
    "targetAudience": "Athletes, gym enthusiasts, runners and active individuals",
    "targetAudienceHi": "जिम जाने वाले युवाओं, धावकों और फिटनेस उत्साही व्यक्तियों हेतु",
    "price": "₹400",
    "isConfirmedPrice": true,
    "testsIncluded": [
      "HY FITNESS-A"
    ],
    "testsIncludedHi": [
      "HY FITNESS-A"
    ],
    "description": "Comprehensive diagnostic profile for HY FITNESS-A conducted with clinical accuracy and 20% discount on standard MRP at Pawan Research Laboratory.",
    "descriptionHi": "पवन रिसर्च लैबोरेटरी में 20% एमआरपी छूट के साथ HY FITNESS-A का संपूर्ण नैदानिक हेल्थ पैकेज।",
    "sampleRequired": "Blood & Urine specimen as required by protocol",
    "recommendedFor": "Preventive healthcare & periodic screening",
    "mrp": 500,
    "discountedPrice": 400,
    "discountPercent": 20
  },
  {
    "id": "pkg-17",
    "name": "HY FITNESS C PRO",
    "nameHi": "HY FITNESS C PRO",
    "type": "fitness",
    "targetAudience": "Athletes, gym enthusiasts, runners and active individuals",
    "targetAudienceHi": "जिम जाने वाले युवाओं, धावकों और फिटनेस उत्साही व्यक्तियों हेतु",
    "price": "₹1280",
    "isConfirmedPrice": true,
    "testsIncluded": [
      "HY FITNESS C PRO"
    ],
    "testsIncludedHi": [
      "HY FITNESS C PRO"
    ],
    "description": "Comprehensive diagnostic profile for HY FITNESS C PRO conducted with clinical accuracy and 20% discount on standard MRP at Pawan Research Laboratory.",
    "descriptionHi": "पवन रिसर्च लैबोरेटरी में 20% एमआरपी छूट के साथ HY FITNESS C PRO का संपूर्ण नैदानिक हेल्थ पैकेज।",
    "sampleRequired": "Blood & Urine specimen as required by protocol",
    "recommendedFor": "Preventive healthcare & periodic screening",
    "mrp": 1600,
    "discountedPrice": 1280,
    "discountPercent": 20
  },
  {
    "id": "pkg-18",
    "name": "HY FIT PACK -B",
    "nameHi": "HY FIT PACK -B",
    "type": "fitness",
    "targetAudience": "Athletes, gym enthusiasts, runners and active individuals",
    "targetAudienceHi": "जिम जाने वाले युवाओं, धावकों और फिटनेस उत्साही व्यक्तियों हेतु",
    "price": "₹1080",
    "isConfirmedPrice": true,
    "testsIncluded": [
      "HY FIT PACK -B"
    ],
    "testsIncludedHi": [
      "HY FIT PACK -B"
    ],
    "description": "Comprehensive diagnostic profile for HY FIT PACK -B conducted with clinical accuracy and 20% discount on standard MRP at Pawan Research Laboratory.",
    "descriptionHi": "पवन रिसर्च लैबोरेटरी में 20% एमआरपी छूट के साथ HY FIT PACK -B का संपूर्ण नैदानिक हेल्थ पैकेज।",
    "sampleRequired": "Blood & Urine specimen as required by protocol",
    "recommendedFor": "Preventive healthcare & periodic screening",
    "mrp": 1350,
    "discountedPrice": 1080,
    "discountPercent": 20
  },
  {
    "id": "pkg-19",
    "name": "HY FIT PACK -A",
    "nameHi": "HY FIT PACK -A",
    "type": "fitness",
    "targetAudience": "Athletes, gym enthusiasts, runners and active individuals",
    "targetAudienceHi": "जिम जाने वाले युवाओं, धावकों और फिटनेस उत्साही व्यक्तियों हेतु",
    "price": "₹760",
    "isConfirmedPrice": true,
    "testsIncluded": [
      "HY FIT PACK -A"
    ],
    "testsIncludedHi": [
      "HY FIT PACK -A"
    ],
    "description": "Comprehensive diagnostic profile for HY FIT PACK -A conducted with clinical accuracy and 20% discount on standard MRP at Pawan Research Laboratory.",
    "descriptionHi": "पवन रिसर्च लैबोरेटरी में 20% एमआरपी छूट के साथ HY FIT PACK -A का संपूर्ण नैदानिक हेल्थ पैकेज।",
    "sampleRequired": "Blood & Urine specimen as required by protocol",
    "recommendedFor": "Preventive healthcare & periodic screening",
    "mrp": 950,
    "discountedPrice": 760,
    "discountPercent": 20
  },
  {
    "id": "pkg-20",
    "name": "HY FITNESS-3",
    "nameHi": "HY FITNESS-3",
    "type": "fitness",
    "targetAudience": "Athletes, gym enthusiasts, runners and active individuals",
    "targetAudienceHi": "जिम जाने वाले युवाओं, धावकों और फिटनेस उत्साही व्यक्तियों हेतु",
    "price": "₹2400",
    "isConfirmedPrice": true,
    "testsIncluded": [
      "HY FITNESS-3"
    ],
    "testsIncludedHi": [
      "HY FITNESS-3"
    ],
    "description": "Comprehensive diagnostic profile for HY FITNESS-3 conducted with clinical accuracy and 20% discount on standard MRP at Pawan Research Laboratory.",
    "descriptionHi": "पवन रिसर्च लैबोरेटरी में 20% एमआरपी छूट के साथ HY FITNESS-3 का संपूर्ण नैदानिक हेल्थ पैकेज।",
    "sampleRequired": "Blood & Urine specimen as required by protocol",
    "recommendedFor": "Preventive healthcare & periodic screening",
    "mrp": 3000,
    "discountedPrice": 2400,
    "discountPercent": 20
  },
  {
    "id": "pkg-21",
    "name": "HY FITNESS-2",
    "nameHi": "HY FITNESS-2",
    "type": "fitness",
    "targetAudience": "Athletes, gym enthusiasts, runners and active individuals",
    "targetAudienceHi": "जिम जाने वाले युवाओं, धावकों और फिटनेस उत्साही व्यक्तियों हेतु",
    "price": "₹1200",
    "isConfirmedPrice": true,
    "testsIncluded": [
      "HY FITNESS-2"
    ],
    "testsIncludedHi": [
      "HY FITNESS-2"
    ],
    "description": "Comprehensive diagnostic profile for HY FITNESS-2 conducted with clinical accuracy and 20% discount on standard MRP at Pawan Research Laboratory.",
    "descriptionHi": "पवन रिसर्च लैबोरेटरी में 20% एमआरपी छूट के साथ HY FITNESS-2 का संपूर्ण नैदानिक हेल्थ पैकेज।",
    "sampleRequired": "Blood & Urine specimen as required by protocol",
    "recommendedFor": "Preventive healthcare & periodic screening",
    "mrp": 1500,
    "discountedPrice": 1200,
    "discountPercent": 20
  },
  {
    "id": "pkg-22",
    "name": "HY FITNESS-1",
    "nameHi": "HY FITNESS-1",
    "type": "fitness",
    "targetAudience": "Athletes, gym enthusiasts, runners and active individuals",
    "targetAudienceHi": "जिम जाने वाले युवाओं, धावकों और फिटनेस उत्साही व्यक्तियों हेतु",
    "price": "₹800",
    "isConfirmedPrice": true,
    "testsIncluded": [
      "HY FITNESS-1"
    ],
    "testsIncludedHi": [
      "HY FITNESS-1"
    ],
    "description": "Comprehensive diagnostic profile for HY FITNESS-1 conducted with clinical accuracy and 20% discount on standard MRP at Pawan Research Laboratory.",
    "descriptionHi": "पवन रिसर्च लैबोरेटरी में 20% एमआरपी छूट के साथ HY FITNESS-1 का संपूर्ण नैदानिक हेल्थ पैकेज।",
    "sampleRequired": "Blood & Urine specimen as required by protocol",
    "recommendedFor": "Preventive healthcare & periodic screening",
    "mrp": 1000,
    "discountedPrice": 800,
    "discountPercent": 20
  },
  {
    "id": "pkg-23",
    "name": "HY FITNESS-4",
    "nameHi": "HY FITNESS-4",
    "type": "fitness",
    "targetAudience": "Athletes, gym enthusiasts, runners and active individuals",
    "targetAudienceHi": "जिम जाने वाले युवाओं, धावकों और फिटनेस उत्साही व्यक्तियों हेतु",
    "price": "₹3200",
    "isConfirmedPrice": true,
    "testsIncluded": [
      "HY FITNESS-4"
    ],
    "testsIncludedHi": [
      "HY FITNESS-4"
    ],
    "description": "Comprehensive diagnostic profile for HY FITNESS-4 conducted with clinical accuracy and 20% discount on standard MRP at Pawan Research Laboratory.",
    "descriptionHi": "पवन रिसर्च लैबोरेटरी में 20% एमआरपी छूट के साथ HY FITNESS-4 का संपूर्ण नैदानिक हेल्थ पैकेज।",
    "sampleRequired": "Blood & Urine specimen as required by protocol",
    "recommendedFor": "Preventive healthcare & periodic screening",
    "mrp": 4000,
    "discountedPrice": 3200,
    "discountPercent": 20
  },
  {
    "id": "pkg-24",
    "name": "HY FITNESS-1.3",
    "nameHi": "HY FITNESS-1.3",
    "type": "fitness",
    "targetAudience": "Athletes, gym enthusiasts, runners and active individuals",
    "targetAudienceHi": "जिम जाने वाले युवाओं, धावकों और फिटनेस उत्साही व्यक्तियों हेतु",
    "price": "₹2400",
    "isConfirmedPrice": true,
    "testsIncluded": [
      "HY FITNESS-1.3"
    ],
    "testsIncludedHi": [
      "HY FITNESS-1.3"
    ],
    "description": "Comprehensive diagnostic profile for HY FITNESS-1.3 conducted with clinical accuracy and 20% discount on standard MRP at Pawan Research Laboratory.",
    "descriptionHi": "पवन रिसर्च लैबोरेटरी में 20% एमआरपी छूट के साथ HY FITNESS-1.3 का संपूर्ण नैदानिक हेल्थ पैकेज।",
    "sampleRequired": "Blood & Urine specimen as required by protocol",
    "recommendedFor": "Preventive healthcare & periodic screening",
    "mrp": 3000,
    "discountedPrice": 2400,
    "discountPercent": 20
  },
  {
    "id": "pkg-25",
    "name": "HY FITNESS-1.2",
    "nameHi": "HY FITNESS-1.2",
    "type": "fitness",
    "targetAudience": "Athletes, gym enthusiasts, runners and active individuals",
    "targetAudienceHi": "जिम जाने वाले युवाओं, धावकों और फिटनेस उत्साही व्यक्तियों हेतु",
    "price": "₹1600",
    "isConfirmedPrice": true,
    "testsIncluded": [
      "HY FITNESS-1.2"
    ],
    "testsIncludedHi": [
      "HY FITNESS-1.2"
    ],
    "description": "Comprehensive diagnostic profile for HY FITNESS-1.2 conducted with clinical accuracy and 20% discount on standard MRP at Pawan Research Laboratory.",
    "descriptionHi": "पवन रिसर्च लैबोरेटरी में 20% एमआरपी छूट के साथ HY FITNESS-1.2 का संपूर्ण नैदानिक हेल्थ पैकेज।",
    "sampleRequired": "Blood & Urine specimen as required by protocol",
    "recommendedFor": "Preventive healthcare & periodic screening",
    "mrp": 2000,
    "discountedPrice": 1600,
    "discountPercent": 20
  },
  {
    "id": "pkg-26",
    "name": "HY FITNESS-1.1",
    "nameHi": "HY FITNESS-1.1",
    "type": "fitness",
    "targetAudience": "Athletes, gym enthusiasts, runners and active individuals",
    "targetAudienceHi": "जिम जाने वाले युवाओं, धावकों और फिटनेस उत्साही व्यक्तियों हेतु",
    "price": "₹960",
    "isConfirmedPrice": true,
    "testsIncluded": [
      "HY FITNESS-1.1"
    ],
    "testsIncludedHi": [
      "HY FITNESS-1.1"
    ],
    "description": "Comprehensive diagnostic profile for HY FITNESS-1.1 conducted with clinical accuracy and 20% discount on standard MRP at Pawan Research Laboratory.",
    "descriptionHi": "पवन रिसर्च लैबोरेटरी में 20% एमआरपी छूट के साथ HY FITNESS-1.1 का संपूर्ण नैदानिक हेल्थ पैकेज।",
    "sampleRequired": "Blood & Urine specimen as required by protocol",
    "recommendedFor": "Preventive healthcare & periodic screening",
    "mrp": 1200,
    "discountedPrice": 960,
    "discountPercent": 20
  },
  {
    "id": "pkg-27",
    "name": "1.3 Fitness Advance",
    "nameHi": "1.3 Fitness Advance",
    "type": "fitness",
    "targetAudience": "Athletes, gym enthusiasts, runners and active individuals",
    "targetAudienceHi": "जिम जाने वाले युवाओं, धावकों और फिटनेस उत्साही व्यक्तियों हेतु",
    "price": "₹2400",
    "isConfirmedPrice": true,
    "testsIncluded": [
      "1.3 Fitness Advance"
    ],
    "testsIncludedHi": [
      "1.3 Fitness Advance"
    ],
    "description": "Comprehensive diagnostic profile for 1.3 Fitness Advance conducted with clinical accuracy and 20% discount on standard MRP at Pawan Research Laboratory.",
    "descriptionHi": "पवन रिसर्च लैबोरेटरी में 20% एमआरपी छूट के साथ 1.3 Fitness Advance का संपूर्ण नैदानिक हेल्थ पैकेज।",
    "sampleRequired": "Blood & Urine specimen as required by protocol",
    "recommendedFor": "Preventive healthcare & periodic screening",
    "mrp": 3000,
    "discountedPrice": 2400,
    "discountPercent": 20
  },
  {
    "id": "pkg-28",
    "name": "ANC PROFILE",
    "nameHi": "ANC PROFILE",
    "type": "wellness",
    "targetAudience": "Adults, families, seniors & individuals seeking preventive screening",
    "targetAudienceHi": "वयस्क, वरिष्ठ नागरिक एवं नियमित स्वास्थ्य परीक्षण चाहने वाले",
    "price": "₹1840",
    "isConfirmedPrice": true,
    "testsIncluded": [
      "ANC PROFILE"
    ],
    "testsIncludedHi": [
      "ANC PROFILE"
    ],
    "description": "Comprehensive diagnostic profile for ANC PROFILE conducted with clinical accuracy and 20% discount on standard MRP at Pawan Research Laboratory.",
    "descriptionHi": "पवन रिसर्च लैबोरेटरी में 20% एमआरपी छूट के साथ ANC PROFILE का संपूर्ण नैदानिक हेल्थ पैकेज।",
    "sampleRequired": "Blood & Urine specimen as required by protocol",
    "recommendedFor": "Preventive healthcare & periodic screening",
    "mrp": 2300,
    "discountedPrice": 1840,
    "discountPercent": 20
  },
  {
    "id": "pkg-29",
    "name": "HY FEVER -1",
    "nameHi": "HY FEVER -1",
    "type": "wellness",
    "targetAudience": "Adults, families, seniors & individuals seeking preventive screening",
    "targetAudienceHi": "वयस्क, वरिष्ठ नागरिक एवं नियमित स्वास्थ्य परीक्षण चाहने वाले",
    "price": "₹600",
    "isConfirmedPrice": true,
    "testsIncluded": [
      "HY FEVER -1"
    ],
    "testsIncludedHi": [
      "HY FEVER -1"
    ],
    "description": "Comprehensive diagnostic profile for HY FEVER -1 conducted with clinical accuracy and 20% discount on standard MRP at Pawan Research Laboratory.",
    "descriptionHi": "पवन रिसर्च लैबोरेटरी में 20% एमआरपी छूट के साथ HY FEVER -1 का संपूर्ण नैदानिक हेल्थ पैकेज।",
    "sampleRequired": "Blood & Urine specimen as required by protocol",
    "recommendedFor": "Preventive healthcare & periodic screening",
    "mrp": 750,
    "discountedPrice": 600,
    "discountPercent": 20
  },
  {
    "id": "pkg-30",
    "name": "HY FEVER -2",
    "nameHi": "HY FEVER -2",
    "type": "wellness",
    "targetAudience": "Adults, families, seniors & individuals seeking preventive screening",
    "targetAudienceHi": "वयस्क, वरिष्ठ नागरिक एवं नियमित स्वास्थ्य परीक्षण चाहने वाले",
    "price": "₹1200",
    "isConfirmedPrice": true,
    "testsIncluded": [
      "HY FEVER -2"
    ],
    "testsIncludedHi": [
      "HY FEVER -2"
    ],
    "description": "Comprehensive diagnostic profile for HY FEVER -2 conducted with clinical accuracy and 20% discount on standard MRP at Pawan Research Laboratory.",
    "descriptionHi": "पवन रिसर्च लैबोरेटरी में 20% एमआरपी छूट के साथ HY FEVER -2 का संपूर्ण नैदानिक हेल्थ पैकेज।",
    "sampleRequired": "Blood & Urine specimen as required by protocol",
    "recommendedFor": "Preventive healthcare & periodic screening",
    "mrp": 1500,
    "discountedPrice": 1200,
    "discountPercent": 20
  },
  {
    "id": "pkg-31",
    "name": "HY FEVER -3",
    "nameHi": "HY FEVER -3",
    "type": "wellness",
    "targetAudience": "Adults, families, seniors & individuals seeking preventive screening",
    "targetAudienceHi": "वयस्क, वरिष्ठ नागरिक एवं नियमित स्वास्थ्य परीक्षण चाहने वाले",
    "price": "₹1440",
    "isConfirmedPrice": true,
    "testsIncluded": [
      "HY FEVER -3"
    ],
    "testsIncludedHi": [
      "HY FEVER -3"
    ],
    "description": "Comprehensive diagnostic profile for HY FEVER -3 conducted with clinical accuracy and 20% discount on standard MRP at Pawan Research Laboratory.",
    "descriptionHi": "पवन रिसर्च लैबोरेटरी में 20% एमआरपी छूट के साथ HY FEVER -3 का संपूर्ण नैदानिक हेल्थ पैकेज।",
    "sampleRequired": "Blood & Urine specimen as required by protocol",
    "recommendedFor": "Preventive healthcare & periodic screening",
    "mrp": 1800,
    "discountedPrice": 1440,
    "discountPercent": 20
  },
  {
    "id": "pkg-32",
    "name": "HY FEVER -4",
    "nameHi": "HY FEVER -4",
    "type": "wellness",
    "targetAudience": "Adults, families, seniors & individuals seeking preventive screening",
    "targetAudienceHi": "वयस्क, वरिष्ठ नागरिक एवं नियमित स्वास्थ्य परीक्षण चाहने वाले",
    "price": "₹1760",
    "isConfirmedPrice": true,
    "testsIncluded": [
      "HY FEVER -4"
    ],
    "testsIncludedHi": [
      "HY FEVER -4"
    ],
    "description": "Comprehensive diagnostic profile for HY FEVER -4 conducted with clinical accuracy and 20% discount on standard MRP at Pawan Research Laboratory.",
    "descriptionHi": "पवन रिसर्च लैबोरेटरी में 20% एमआरपी छूट के साथ HY FEVER -4 का संपूर्ण नैदानिक हेल्थ पैकेज।",
    "sampleRequired": "Blood & Urine specimen as required by protocol",
    "recommendedFor": "Preventive healthcare & periodic screening",
    "mrp": 2200,
    "discountedPrice": 1760,
    "discountPercent": 20
  },
  {
    "id": "pkg-33",
    "name": "HY WOMEN PROFILE",
    "nameHi": "HY WOMEN PROFILE",
    "type": "wellness",
    "targetAudience": "Adults, families, seniors & individuals seeking preventive screening",
    "targetAudienceHi": "वयस्क, वरिष्ठ नागरिक एवं नियमित स्वास्थ्य परीक्षण चाहने वाले",
    "price": "₹1600",
    "isConfirmedPrice": true,
    "testsIncluded": [
      "HY WOMEN PROFILE"
    ],
    "testsIncludedHi": [
      "HY WOMEN PROFILE"
    ],
    "description": "Comprehensive diagnostic profile for HY WOMEN PROFILE conducted with clinical accuracy and 20% discount on standard MRP at Pawan Research Laboratory.",
    "descriptionHi": "पवन रिसर्च लैबोरेटरी में 20% एमआरपी छूट के साथ HY WOMEN PROFILE का संपूर्ण नैदानिक हेल्थ पैकेज।",
    "sampleRequired": "Blood & Urine specimen as required by protocol",
    "recommendedFor": "Preventive healthcare & periodic screening",
    "mrp": 2000,
    "discountedPrice": 1600,
    "discountPercent": 20
  },
  {
    "id": "pkg-34",
    "name": "WELLENESS Testing",
    "nameHi": "WELLENESS Testing",
    "type": "wellness",
    "targetAudience": "Adults, families, seniors & individuals seeking preventive screening",
    "targetAudienceHi": "वयस्क, वरिष्ठ नागरिक एवं नियमित स्वास्थ्य परीक्षण चाहने वाले",
    "price": "₹1440",
    "isConfirmedPrice": true,
    "testsIncluded": [
      "WELLENESS Testing"
    ],
    "testsIncludedHi": [
      "WELLENESS Testing"
    ],
    "description": "Comprehensive diagnostic profile for WELLENESS Testing conducted with clinical accuracy and 20% discount on standard MRP at Pawan Research Laboratory.",
    "descriptionHi": "पवन रिसर्च लैबोरेटरी में 20% एमआरपी छूट के साथ WELLENESS Testing का संपूर्ण नैदानिक हेल्थ पैकेज।",
    "sampleRequired": "Blood & Urine specimen as required by protocol",
    "recommendedFor": "Preventive healthcare & periodic screening",
    "mrp": 1800,
    "discountedPrice": 1440,
    "discountPercent": 20
  },
  {
    "id": "pkg-35",
    "name": "WELLNESS-1 PLUS",
    "nameHi": "WELLNESS-1 PLUS",
    "type": "wellness",
    "targetAudience": "Adults, families, seniors & individuals seeking preventive screening",
    "targetAudienceHi": "वयस्क, वरिष्ठ नागरिक एवं नियमित स्वास्थ्य परीक्षण चाहने वाले",
    "price": "₹800",
    "isConfirmedPrice": true,
    "testsIncluded": [
      "WELLNESS-1 PLUS"
    ],
    "testsIncludedHi": [
      "WELLNESS-1 PLUS"
    ],
    "description": "Comprehensive diagnostic profile for WELLNESS-1 PLUS conducted with clinical accuracy and 20% discount on standard MRP at Pawan Research Laboratory.",
    "descriptionHi": "पवन रिसर्च लैबोरेटरी में 20% एमआरपी छूट के साथ WELLNESS-1 PLUS का संपूर्ण नैदानिक हेल्थ पैकेज।",
    "sampleRequired": "Blood & Urine specimen as required by protocol",
    "recommendedFor": "Preventive healthcare & periodic screening",
    "mrp": 1000,
    "discountedPrice": 800,
    "discountPercent": 20
  },
  {
    "id": "pkg-36",
    "name": "APLA PROFILE",
    "nameHi": "APLA PROFILE",
    "type": "wellness",
    "targetAudience": "Adults, families, seniors & individuals seeking preventive screening",
    "targetAudienceHi": "वयस्क, वरिष्ठ नागरिक एवं नियमित स्वास्थ्य परीक्षण चाहने वाले",
    "price": "₹3200",
    "isConfirmedPrice": true,
    "testsIncluded": [
      "APLA PROFILE"
    ],
    "testsIncludedHi": [
      "APLA PROFILE"
    ],
    "description": "Comprehensive diagnostic profile for APLA PROFILE conducted with clinical accuracy and 20% discount on standard MRP at Pawan Research Laboratory.",
    "descriptionHi": "पवन रिसर्च लैबोरेटरी में 20% एमआरपी छूट के साथ APLA PROFILE का संपूर्ण नैदानिक हेल्थ पैकेज।",
    "sampleRequired": "Blood & Urine specimen as required by protocol",
    "recommendedFor": "Preventive healthcare & periodic screening",
    "mrp": 4000,
    "discountedPrice": 3200,
    "discountPercent": 20
  },
  {
    "id": "pkg-37",
    "name": "HY FITNESS SMART-A",
    "nameHi": "HY FITNESS SMART-A",
    "type": "fitness",
    "targetAudience": "Athletes, gym enthusiasts, runners and active individuals",
    "targetAudienceHi": "जिम जाने वाले युवाओं, धावकों और फिटनेस उत्साही व्यक्तियों हेतु",
    "price": "₹2040",
    "isConfirmedPrice": true,
    "testsIncluded": [
      "HY FITNESS SMART-A"
    ],
    "testsIncludedHi": [
      "HY FITNESS SMART-A"
    ],
    "description": "Comprehensive diagnostic profile for HY FITNESS SMART-A conducted with clinical accuracy and 20% discount on standard MRP at Pawan Research Laboratory.",
    "descriptionHi": "पवन रिसर्च लैबोरेटरी में 20% एमआरपी छूट के साथ HY FITNESS SMART-A का संपूर्ण नैदानिक हेल्थ पैकेज।",
    "sampleRequired": "Blood & Urine specimen as required by protocol",
    "recommendedFor": "Preventive healthcare & periodic screening",
    "mrp": 2550,
    "discountedPrice": 2040,
    "discountPercent": 20
  },
  {
    "id": "pkg-38",
    "name": "HY FITNESS SMART",
    "nameHi": "HY FITNESS SMART",
    "type": "fitness",
    "targetAudience": "Athletes, gym enthusiasts, runners and active individuals",
    "targetAudienceHi": "जिम जाने वाले युवाओं, धावकों और फिटनेस उत्साही व्यक्तियों हेतु",
    "price": "₹1920",
    "isConfirmedPrice": true,
    "testsIncluded": [
      "HY FITNESS SMART"
    ],
    "testsIncludedHi": [
      "HY FITNESS SMART"
    ],
    "description": "Comprehensive diagnostic profile for HY FITNESS SMART conducted with clinical accuracy and 20% discount on standard MRP at Pawan Research Laboratory.",
    "descriptionHi": "पवन रिसर्च लैबोरेटरी में 20% एमआरपी छूट के साथ HY FITNESS SMART का संपूर्ण नैदानिक हेल्थ पैकेज।",
    "sampleRequired": "Blood & Urine specimen as required by protocol",
    "recommendedFor": "Preventive healthcare & periodic screening",
    "mrp": 2400,
    "discountedPrice": 1920,
    "discountPercent": 20
  },
  {
    "id": "pkg-39",
    "name": "HY FITNESS SMART 3",
    "nameHi": "HY FITNESS SMART 3",
    "type": "fitness",
    "targetAudience": "Athletes, gym enthusiasts, runners and active individuals",
    "targetAudienceHi": "जिम जाने वाले युवाओं, धावकों और फिटनेस उत्साही व्यक्तियों हेतु",
    "price": "₹2560",
    "isConfirmedPrice": true,
    "testsIncluded": [
      "HY FITNESS SMART 3"
    ],
    "testsIncludedHi": [
      "HY FITNESS SMART 3"
    ],
    "description": "Comprehensive diagnostic profile for HY FITNESS SMART 3 conducted with clinical accuracy and 20% discount on standard MRP at Pawan Research Laboratory.",
    "descriptionHi": "पवन रिसर्च लैबोरेटरी में 20% एमआरपी छूट के साथ HY FITNESS SMART 3 का संपूर्ण नैदानिक हेल्थ पैकेज।",
    "sampleRequired": "Blood & Urine specimen as required by protocol",
    "recommendedFor": "Preventive healthcare & periodic screening",
    "mrp": 3200,
    "discountedPrice": 2560,
    "discountPercent": 20
  },
  {
    "id": "pkg-40",
    "name": "WELLNESS SMART",
    "nameHi": "WELLNESS SMART",
    "type": "wellness",
    "targetAudience": "Adults, families, seniors & individuals seeking preventive screening",
    "targetAudienceHi": "वयस्क, वरिष्ठ नागरिक एवं नियमित स्वास्थ्य परीक्षण चाहने वाले",
    "price": "₹1200",
    "isConfirmedPrice": true,
    "testsIncluded": [
      "WELLNESS SMART"
    ],
    "testsIncludedHi": [
      "WELLNESS SMART"
    ],
    "description": "Comprehensive diagnostic profile for WELLNESS SMART conducted with clinical accuracy and 20% discount on standard MRP at Pawan Research Laboratory.",
    "descriptionHi": "पवन रिसर्च लैबोरेटरी में 20% एमआरपी छूट के साथ WELLNESS SMART का संपूर्ण नैदानिक हेल्थ पैकेज।",
    "sampleRequired": "Blood & Urine specimen as required by protocol",
    "recommendedFor": "Preventive healthcare & periodic screening",
    "mrp": 1500,
    "discountedPrice": 1200,
    "discountPercent": 20
  },
  {
    "id": "pkg-41",
    "name": "HY FITNESS-1.3 +PSA",
    "nameHi": "HY FITNESS-1.3 +PSA",
    "type": "fitness",
    "targetAudience": "Athletes, gym enthusiasts, runners and active individuals",
    "targetAudienceHi": "जिम जाने वाले युवाओं, धावकों और फिटनेस उत्साही व्यक्तियों हेतु",
    "price": "₹800",
    "isConfirmedPrice": true,
    "testsIncluded": [
      "HY FITNESS-1.3 +PSA"
    ],
    "testsIncludedHi": [
      "HY FITNESS-1.3 +PSA"
    ],
    "description": "Comprehensive diagnostic profile for HY FITNESS-1.3 +PSA conducted with clinical accuracy and 20% discount on standard MRP at Pawan Research Laboratory.",
    "descriptionHi": "पवन रिसर्च लैबोरेटरी में 20% एमआरपी छूट के साथ HY FITNESS-1.3 +PSA का संपूर्ण नैदानिक हेल्थ पैकेज।",
    "sampleRequired": "Blood & Urine specimen as required by protocol",
    "recommendedFor": "Preventive healthcare & periodic screening",
    "mrp": 1000,
    "discountedPrice": 800,
    "discountPercent": 20
  },
  {
    "id": "pkg-42",
    "name": "HY FITNESS 1.3 + CRP",
    "nameHi": "HY FITNESS 1.3 + CRP",
    "type": "fitness",
    "targetAudience": "Athletes, gym enthusiasts, runners and active individuals",
    "targetAudienceHi": "जिम जाने वाले युवाओं, धावकों और फिटनेस उत्साही व्यक्तियों हेतु",
    "price": "₹1600",
    "isConfirmedPrice": true,
    "testsIncluded": [
      "HY FITNESS 1.3 + CRP"
    ],
    "testsIncludedHi": [
      "HY FITNESS 1.3 + CRP"
    ],
    "description": "Comprehensive diagnostic profile for HY FITNESS 1.3 + CRP conducted with clinical accuracy and 20% discount on standard MRP at Pawan Research Laboratory.",
    "descriptionHi": "पवन रिसर्च लैबोरेटरी में 20% एमआरपी छूट के साथ HY FITNESS 1.3 + CRP का संपूर्ण नैदानिक हेल्थ पैकेज।",
    "sampleRequired": "Blood & Urine specimen as required by protocol",
    "recommendedFor": "Preventive healthcare & periodic screening",
    "mrp": 2000,
    "discountedPrice": 1600,
    "discountPercent": 20
  },
  {
    "id": "pkg-43",
    "name": "HY FITNESS 1.0",
    "nameHi": "HY FITNESS 1.0",
    "type": "fitness",
    "targetAudience": "Athletes, gym enthusiasts, runners and active individuals",
    "targetAudienceHi": "जिम जाने वाले युवाओं, धावकों और फिटनेस उत्साही व्यक्तियों हेतु",
    "price": "₹800",
    "isConfirmedPrice": true,
    "testsIncluded": [
      "HY FITNESS 1.0"
    ],
    "testsIncludedHi": [
      "HY FITNESS 1.0"
    ],
    "description": "Comprehensive diagnostic profile for HY FITNESS 1.0 conducted with clinical accuracy and 20% discount on standard MRP at Pawan Research Laboratory.",
    "descriptionHi": "पवन रिसर्च लैबोरेटरी में 20% एमआरपी छूट के साथ HY FITNESS 1.0 का संपूर्ण नैदानिक हेल्थ पैकेज।",
    "sampleRequired": "Blood & Urine specimen as required by protocol",
    "recommendedFor": "Preventive healthcare & periodic screening",
    "mrp": 1000,
    "discountedPrice": 800,
    "discountPercent": 20
  },
  {
    "id": "pkg-44",
    "name": "HY FITNESS 4.1",
    "nameHi": "HY FITNESS 4.1",
    "type": "fitness",
    "targetAudience": "Athletes, gym enthusiasts, runners and active individuals",
    "targetAudienceHi": "जिम जाने वाले युवाओं, धावकों और फिटनेस उत्साही व्यक्तियों हेतु",
    "price": "₹2400",
    "isConfirmedPrice": true,
    "testsIncluded": [
      "HY FITNESS 4.1"
    ],
    "testsIncludedHi": [
      "HY FITNESS 4.1"
    ],
    "description": "Comprehensive diagnostic profile for HY FITNESS 4.1 conducted with clinical accuracy and 20% discount on standard MRP at Pawan Research Laboratory.",
    "descriptionHi": "पवन रिसर्च लैबोरेटरी में 20% एमआरपी छूट के साथ HY FITNESS 4.1 का संपूर्ण नैदानिक हेल्थ पैकेज।",
    "sampleRequired": "Blood & Urine specimen as required by protocol",
    "recommendedFor": "Preventive healthcare & periodic screening",
    "mrp": 3000,
    "discountedPrice": 2400,
    "discountPercent": 20
  },
  {
    "id": "pkg-45",
    "name": "WELLNESS-1.1 MINI",
    "nameHi": "WELLNESS-1.1 MINI",
    "type": "wellness",
    "targetAudience": "Adults, families, seniors & individuals seeking preventive screening",
    "targetAudienceHi": "वयस्क, वरिष्ठ नागरिक एवं नियमित स्वास्थ्य परीक्षण चाहने वाले",
    "price": "₹640",
    "isConfirmedPrice": true,
    "testsIncluded": [
      "WELLNESS-1.1 MINI"
    ],
    "testsIncludedHi": [
      "WELLNESS-1.1 MINI"
    ],
    "description": "Comprehensive diagnostic profile for WELLNESS-1.1 MINI conducted with clinical accuracy and 20% discount on standard MRP at Pawan Research Laboratory.",
    "descriptionHi": "पवन रिसर्च लैबोरेटरी में 20% एमआरपी छूट के साथ WELLNESS-1.1 MINI का संपूर्ण नैदानिक हेल्थ पैकेज।",
    "sampleRequired": "Blood & Urine specimen as required by protocol",
    "recommendedFor": "Preventive healthcare & periodic screening",
    "mrp": 800,
    "discountedPrice": 640,
    "discountPercent": 20
  },
  {
    "id": "pkg-46",
    "name": "WELLNESS 1.1 CBC+ GLUCOSE",
    "nameHi": "WELLNESS 1.1 CBC+ GLUCOSE",
    "type": "wellness",
    "targetAudience": "Adults, families, seniors & individuals seeking preventive screening",
    "targetAudienceHi": "वयस्क, वरिष्ठ नागरिक एवं नियमित स्वास्थ्य परीक्षण चाहने वाले",
    "price": "₹880",
    "isConfirmedPrice": true,
    "testsIncluded": [
      "WELLNESS 1.1 CBC+ GLUCOSE"
    ],
    "testsIncludedHi": [
      "WELLNESS 1.1 CBC+ GLUCOSE"
    ],
    "description": "Comprehensive diagnostic profile for WELLNESS 1.1 CBC+ GLUCOSE conducted with clinical accuracy and 20% discount on standard MRP at Pawan Research Laboratory.",
    "descriptionHi": "पवन रिसर्च लैबोरेटरी में 20% एमआरपी छूट के साथ WELLNESS 1.1 CBC+ GLUCOSE का संपूर्ण नैदानिक हेल्थ पैकेज।",
    "sampleRequired": "Blood & Urine specimen as required by protocol",
    "recommendedFor": "Preventive healthcare & periodic screening",
    "mrp": 1100,
    "discountedPrice": 880,
    "discountPercent": 20
  },
  {
    "id": "pkg-47",
    "name": "HY SUMMER PROFILE",
    "nameHi": "HY SUMMER PROFILE",
    "type": "wellness",
    "targetAudience": "Adults, families, seniors & individuals seeking preventive screening",
    "targetAudienceHi": "वयस्क, वरिष्ठ नागरिक एवं नियमित स्वास्थ्य परीक्षण चाहने वाले",
    "price": "₹960",
    "isConfirmedPrice": true,
    "testsIncluded": [
      "HY SUMMER PROFILE"
    ],
    "testsIncludedHi": [
      "HY SUMMER PROFILE"
    ],
    "description": "Comprehensive diagnostic profile for HY SUMMER PROFILE conducted with clinical accuracy and 20% discount on standard MRP at Pawan Research Laboratory.",
    "descriptionHi": "पवन रिसर्च लैबोरेटरी में 20% एमआरपी छूट के साथ HY SUMMER PROFILE का संपूर्ण नैदानिक हेल्थ पैकेज।",
    "sampleRequired": "Blood & Urine specimen as required by protocol",
    "recommendedFor": "Preventive healthcare & periodic screening",
    "mrp": 1200,
    "discountedPrice": 960,
    "discountPercent": 20
  },
  {
    "id": "pkg-48",
    "name": "SUMMER PROFILE",
    "nameHi": "SUMMER PROFILE",
    "type": "wellness",
    "targetAudience": "Adults, families, seniors & individuals seeking preventive screening",
    "targetAudienceHi": "वयस्क, वरिष्ठ नागरिक एवं नियमित स्वास्थ्य परीक्षण चाहने वाले",
    "price": "₹560",
    "isConfirmedPrice": true,
    "testsIncluded": [
      "SUMMER PROFILE"
    ],
    "testsIncludedHi": [
      "SUMMER PROFILE"
    ],
    "description": "Comprehensive diagnostic profile for SUMMER PROFILE conducted with clinical accuracy and 20% discount on standard MRP at Pawan Research Laboratory.",
    "descriptionHi": "पवन रिसर्च लैबोरेटरी में 20% एमआरपी छूट के साथ SUMMER PROFILE का संपूर्ण नैदानिक हेल्थ पैकेज।",
    "sampleRequired": "Blood & Urine specimen as required by protocol",
    "recommendedFor": "Preventive healthcare & periodic screening",
    "mrp": 700,
    "discountedPrice": 560,
    "discountPercent": 20
  },
  {
    "id": "pkg-49",
    "name": "PCOD PROFILE",
    "nameHi": "PCOD PROFILE",
    "type": "wellness",
    "targetAudience": "Adults, families, seniors & individuals seeking preventive screening",
    "targetAudienceHi": "वयस्क, वरिष्ठ नागरिक एवं नियमित स्वास्थ्य परीक्षण चाहने वाले",
    "price": "₹3200",
    "isConfirmedPrice": true,
    "testsIncluded": [
      "PCOD PROFILE"
    ],
    "testsIncludedHi": [
      "PCOD PROFILE"
    ],
    "description": "Comprehensive diagnostic profile for PCOD PROFILE conducted with clinical accuracy and 20% discount on standard MRP at Pawan Research Laboratory.",
    "descriptionHi": "पवन रिसर्च लैबोरेटरी में 20% एमआरपी छूट के साथ PCOD PROFILE का संपूर्ण नैदानिक हेल्थ पैकेज।",
    "sampleRequired": "Blood & Urine specimen as required by protocol",
    "recommendedFor": "Preventive healthcare & periodic screening",
    "mrp": 4000,
    "discountedPrice": 3200,
    "discountPercent": 20
  },
  {
    "id": "pkg-50",
    "name": "PREGNANCY PROFILE",
    "nameHi": "PREGNANCY PROFILE",
    "type": "wellness",
    "targetAudience": "Adults, families, seniors & individuals seeking preventive screening",
    "targetAudienceHi": "वयस्क, वरिष्ठ नागरिक एवं नियमित स्वास्थ्य परीक्षण चाहने वाले",
    "price": "₹1600",
    "isConfirmedPrice": true,
    "testsIncluded": [
      "PREGNANCY PROFILE"
    ],
    "testsIncludedHi": [
      "PREGNANCY PROFILE"
    ],
    "description": "Comprehensive diagnostic profile for PREGNANCY PROFILE conducted with clinical accuracy and 20% discount on standard MRP at Pawan Research Laboratory.",
    "descriptionHi": "पवन रिसर्च लैबोरेटरी में 20% एमआरपी छूट के साथ PREGNANCY PROFILE का संपूर्ण नैदानिक हेल्थ पैकेज।",
    "sampleRequired": "Blood & Urine specimen as required by protocol",
    "recommendedFor": "Preventive healthcare & periodic screening",
    "mrp": 2000,
    "discountedPrice": 1600,
    "discountPercent": 20
  },
  {
    "id": "pkg-51",
    "name": "ARTHRITIS BASIC PANEL",
    "nameHi": "ARTHRITIS BASIC PANEL",
    "type": "wellness",
    "targetAudience": "Adults, families, seniors & individuals seeking preventive screening",
    "targetAudienceHi": "वयस्क, वरिष्ठ नागरिक एवं नियमित स्वास्थ्य परीक्षण चाहने वाले",
    "price": "₹4000",
    "isConfirmedPrice": true,
    "testsIncluded": [
      "ARTHRITIS BASIC PANEL"
    ],
    "testsIncludedHi": [
      "ARTHRITIS BASIC PANEL"
    ],
    "description": "Comprehensive diagnostic profile for ARTHRITIS BASIC PANEL conducted with clinical accuracy and 20% discount on standard MRP at Pawan Research Laboratory.",
    "descriptionHi": "पवन रिसर्च लैबोरेटरी में 20% एमआरपी छूट के साथ ARTHRITIS BASIC PANEL का संपूर्ण नैदानिक हेल्थ पैकेज।",
    "sampleRequired": "Blood & Urine specimen as required by protocol",
    "recommendedFor": "Preventive healthcare & periodic screening",
    "mrp": 5000,
    "discountedPrice": 4000,
    "discountPercent": 20
  },
  {
    "id": "pkg-52",
    "name": "CANCER PANEL (MALE)",
    "nameHi": "CANCER PANEL (MALE)",
    "type": "wellness",
    "targetAudience": "Adults, families, seniors & individuals seeking preventive screening",
    "targetAudienceHi": "वयस्क, वरिष्ठ नागरिक एवं नियमित स्वास्थ्य परीक्षण चाहने वाले",
    "price": "₹4000",
    "isConfirmedPrice": true,
    "testsIncluded": [
      "CANCER PANEL (MALE)"
    ],
    "testsIncludedHi": [
      "CANCER PANEL (MALE)"
    ],
    "description": "Comprehensive diagnostic profile for CANCER PANEL (MALE) conducted with clinical accuracy and 20% discount on standard MRP at Pawan Research Laboratory.",
    "descriptionHi": "पवन रिसर्च लैबोरेटरी में 20% एमआरपी छूट के साथ CANCER PANEL (MALE) का संपूर्ण नैदानिक हेल्थ पैकेज।",
    "sampleRequired": "Blood & Urine specimen as required by protocol",
    "recommendedFor": "Preventive healthcare & periodic screening",
    "mrp": 5000,
    "discountedPrice": 4000,
    "discountPercent": 20
  },
  {
    "id": "pkg-53",
    "name": "ARTHRITIS BASIC PANEL - 2",
    "nameHi": "ARTHRITIS BASIC PANEL - 2",
    "type": "wellness",
    "targetAudience": "Adults, families, seniors & individuals seeking preventive screening",
    "targetAudienceHi": "वयस्क, वरिष्ठ नागरिक एवं नियमित स्वास्थ्य परीक्षण चाहने वाले",
    "price": "₹4800",
    "isConfirmedPrice": true,
    "testsIncluded": [
      "ARTHRITIS BASIC PANEL - 2"
    ],
    "testsIncludedHi": [
      "ARTHRITIS BASIC PANEL - 2"
    ],
    "description": "Comprehensive diagnostic profile for ARTHRITIS BASIC PANEL - 2 conducted with clinical accuracy and 20% discount on standard MRP at Pawan Research Laboratory.",
    "descriptionHi": "पवन रिसर्च लैबोरेटरी में 20% एमआरपी छूट के साथ ARTHRITIS BASIC PANEL - 2 का संपूर्ण नैदानिक हेल्थ पैकेज।",
    "sampleRequired": "Blood & Urine specimen as required by protocol",
    "recommendedFor": "Preventive healthcare & periodic screening",
    "mrp": 6000,
    "discountedPrice": 4800,
    "discountPercent": 20
  },
  {
    "id": "pkg-54",
    "name": "Arthritis first",
    "nameHi": "Arthritis first",
    "type": "wellness",
    "targetAudience": "Adults, families, seniors & individuals seeking preventive screening",
    "targetAudienceHi": "वयस्क, वरिष्ठ नागरिक एवं नियमित स्वास्थ्य परीक्षण चाहने वाले",
    "price": "₹800",
    "isConfirmedPrice": true,
    "testsIncluded": [
      "Arthritis first"
    ],
    "testsIncludedHi": [
      "Arthritis first"
    ],
    "description": "Comprehensive diagnostic profile for Arthritis first conducted with clinical accuracy and 20% discount on standard MRP at Pawan Research Laboratory.",
    "descriptionHi": "पवन रिसर्च लैबोरेटरी में 20% एमआरपी छूट के साथ Arthritis first का संपूर्ण नैदानिक हेल्थ पैकेज।",
    "sampleRequired": "Blood & Urine specimen as required by protocol",
    "recommendedFor": "Preventive healthcare & periodic screening",
    "mrp": 1000,
    "discountedPrice": 800,
    "discountPercent": 20
  },
  {
    "id": "pkg-55",
    "name": "ARTHRITIS PANAL (MINI)",
    "nameHi": "ARTHRITIS PANAL (MINI)",
    "type": "wellness",
    "targetAudience": "Adults, families, seniors & individuals seeking preventive screening",
    "targetAudienceHi": "वयस्क, वरिष्ठ नागरिक एवं नियमित स्वास्थ्य परीक्षण चाहने वाले",
    "price": "₹1200",
    "isConfirmedPrice": true,
    "testsIncluded": [
      "ARTHRITIS PANAL (MINI)"
    ],
    "testsIncludedHi": [
      "ARTHRITIS PANAL (MINI)"
    ],
    "description": "Comprehensive diagnostic profile for ARTHRITIS PANAL (MINI) conducted with clinical accuracy and 20% discount on standard MRP at Pawan Research Laboratory.",
    "descriptionHi": "पवन रिसर्च लैबोरेटरी में 20% एमआरपी छूट के साथ ARTHRITIS PANAL (MINI) का संपूर्ण नैदानिक हेल्थ पैकेज।",
    "sampleRequired": "Blood & Urine specimen as required by protocol",
    "recommendedFor": "Preventive healthcare & periodic screening",
    "mrp": 1500,
    "discountedPrice": 1200,
    "discountPercent": 20
  },
  {
    "id": "pkg-56",
    "name": "ARTHRITIS PANAL I",
    "nameHi": "ARTHRITIS PANAL I",
    "type": "wellness",
    "targetAudience": "Adults, families, seniors & individuals seeking preventive screening",
    "targetAudienceHi": "वयस्क, वरिष्ठ नागरिक एवं नियमित स्वास्थ्य परीक्षण चाहने वाले",
    "price": "₹1200",
    "isConfirmedPrice": true,
    "testsIncluded": [
      "ARTHRITIS PANAL I"
    ],
    "testsIncludedHi": [
      "ARTHRITIS PANAL I"
    ],
    "description": "Comprehensive diagnostic profile for ARTHRITIS PANAL I conducted with clinical accuracy and 20% discount on standard MRP at Pawan Research Laboratory.",
    "descriptionHi": "पवन रिसर्च लैबोरेटरी में 20% एमआरपी छूट के साथ ARTHRITIS PANAL I का संपूर्ण नैदानिक हेल्थ पैकेज।",
    "sampleRequired": "Blood & Urine specimen as required by protocol",
    "recommendedFor": "Preventive healthcare & periodic screening",
    "mrp": 1500,
    "discountedPrice": 1200,
    "discountPercent": 20
  },
  {
    "id": "pkg-57",
    "name": "ARTHRITIS PANAL II",
    "nameHi": "ARTHRITIS PANAL II",
    "type": "wellness",
    "targetAudience": "Adults, families, seniors & individuals seeking preventive screening",
    "targetAudienceHi": "वयस्क, वरिष्ठ नागरिक एवं नियमित स्वास्थ्य परीक्षण चाहने वाले",
    "price": "₹1600",
    "isConfirmedPrice": true,
    "testsIncluded": [
      "ARTHRITIS PANAL II"
    ],
    "testsIncludedHi": [
      "ARTHRITIS PANAL II"
    ],
    "description": "Comprehensive diagnostic profile for ARTHRITIS PANAL II conducted with clinical accuracy and 20% discount on standard MRP at Pawan Research Laboratory.",
    "descriptionHi": "पवन रिसर्च लैबोरेटरी में 20% एमआरपी छूट के साथ ARTHRITIS PANAL II का संपूर्ण नैदानिक हेल्थ पैकेज।",
    "sampleRequired": "Blood & Urine specimen as required by protocol",
    "recommendedFor": "Preventive healthcare & periodic screening",
    "mrp": 2000,
    "discountedPrice": 1600,
    "discountPercent": 20
  },
  {
    "id": "pkg-58",
    "name": "ARTHRITIS PROFILE - A",
    "nameHi": "ARTHRITIS PROFILE - A",
    "type": "wellness",
    "targetAudience": "Adults, families, seniors & individuals seeking preventive screening",
    "targetAudienceHi": "वयस्क, वरिष्ठ नागरिक एवं नियमित स्वास्थ्य परीक्षण चाहने वाले",
    "price": "₹3200",
    "isConfirmedPrice": true,
    "testsIncluded": [
      "ARTHRITIS PROFILE - A"
    ],
    "testsIncludedHi": [
      "ARTHRITIS PROFILE - A"
    ],
    "description": "Comprehensive diagnostic profile for ARTHRITIS PROFILE - A conducted with clinical accuracy and 20% discount on standard MRP at Pawan Research Laboratory.",
    "descriptionHi": "पवन रिसर्च लैबोरेटरी में 20% एमआरपी छूट के साथ ARTHRITIS PROFILE - A का संपूर्ण नैदानिक हेल्थ पैकेज।",
    "sampleRequired": "Blood & Urine specimen as required by protocol",
    "recommendedFor": "Preventive healthcare & periodic screening",
    "mrp": 4000,
    "discountedPrice": 3200,
    "discountPercent": 20
  },
  {
    "id": "pkg-59",
    "name": "ARTHRITIS PROFILE - B",
    "nameHi": "ARTHRITIS PROFILE - B",
    "type": "wellness",
    "targetAudience": "Adults, families, seniors & individuals seeking preventive screening",
    "targetAudienceHi": "वयस्क, वरिष्ठ नागरिक एवं नियमित स्वास्थ्य परीक्षण चाहने वाले",
    "price": "₹4400",
    "isConfirmedPrice": true,
    "testsIncluded": [
      "ARTHRITIS PROFILE - B"
    ],
    "testsIncludedHi": [
      "ARTHRITIS PROFILE - B"
    ],
    "description": "Comprehensive diagnostic profile for ARTHRITIS PROFILE - B conducted with clinical accuracy and 20% discount on standard MRP at Pawan Research Laboratory.",
    "descriptionHi": "पवन रिसर्च लैबोरेटरी में 20% एमआरपी छूट के साथ ARTHRITIS PROFILE - B का संपूर्ण नैदानिक हेल्थ पैकेज।",
    "sampleRequired": "Blood & Urine specimen as required by protocol",
    "recommendedFor": "Preventive healthcare & periodic screening",
    "mrp": 5500,
    "discountedPrice": 4400,
    "discountPercent": 20
  },
  {
    "id": "pkg-60",
    "name": "ARTHRITIS PROFILE - C",
    "nameHi": "ARTHRITIS PROFILE - C",
    "type": "wellness",
    "targetAudience": "Adults, families, seniors & individuals seeking preventive screening",
    "targetAudienceHi": "वयस्क, वरिष्ठ नागरिक एवं नियमित स्वास्थ्य परीक्षण चाहने वाले",
    "price": "₹8000",
    "isConfirmedPrice": true,
    "testsIncluded": [
      "ARTHRITIS PROFILE - C"
    ],
    "testsIncludedHi": [
      "ARTHRITIS PROFILE - C"
    ],
    "description": "Comprehensive diagnostic profile for ARTHRITIS PROFILE - C conducted with clinical accuracy and 20% discount on standard MRP at Pawan Research Laboratory.",
    "descriptionHi": "पवन रिसर्च लैबोरेटरी में 20% एमआरपी छूट के साथ ARTHRITIS PROFILE - C का संपूर्ण नैदानिक हेल्थ पैकेज।",
    "sampleRequired": "Blood & Urine specimen as required by protocol",
    "recommendedFor": "Preventive healthcare & periodic screening",
    "mrp": 10000,
    "discountedPrice": 8000,
    "discountPercent": 20
  },
  {
    "id": "pkg-61",
    "name": "ARTHRITIS PROFILE - M",
    "nameHi": "ARTHRITIS PROFILE - M",
    "type": "wellness",
    "targetAudience": "Adults, families, seniors & individuals seeking preventive screening",
    "targetAudienceHi": "वयस्क, वरिष्ठ नागरिक एवं नियमित स्वास्थ्य परीक्षण चाहने वाले",
    "price": "₹1600",
    "isConfirmedPrice": true,
    "testsIncluded": [
      "ARTHRITIS PROFILE - M"
    ],
    "testsIncludedHi": [
      "ARTHRITIS PROFILE - M"
    ],
    "description": "Comprehensive diagnostic profile for ARTHRITIS PROFILE - M conducted with clinical accuracy and 20% discount on standard MRP at Pawan Research Laboratory.",
    "descriptionHi": "पवन रिसर्च लैबोरेटरी में 20% एमआरपी छूट के साथ ARTHRITIS PROFILE - M का संपूर्ण नैदानिक हेल्थ पैकेज।",
    "sampleRequired": "Blood & Urine specimen as required by protocol",
    "recommendedFor": "Preventive healthcare & periodic screening",
    "mrp": 2000,
    "discountedPrice": 1600,
    "discountPercent": 20
  },
  {
    "id": "pkg-62",
    "name": "ABHI-32",
    "nameHi": "ABHI-32",
    "type": "wellness",
    "targetAudience": "Adults, families, seniors & individuals seeking preventive screening",
    "targetAudienceHi": "वयस्क, वरिष्ठ नागरिक एवं नियमित स्वास्थ्य परीक्षण चाहने वाले",
    "price": "₹800",
    "isConfirmedPrice": true,
    "testsIncluded": [
      "ABHI-32"
    ],
    "testsIncludedHi": [
      "ABHI-32"
    ],
    "description": "Comprehensive diagnostic profile for ABHI-32 conducted with clinical accuracy and 20% discount on standard MRP at Pawan Research Laboratory.",
    "descriptionHi": "पवन रिसर्च लैबोरेटरी में 20% एमआरपी छूट के साथ ABHI-32 का संपूर्ण नैदानिक हेल्थ पैकेज।",
    "sampleRequired": "Blood & Urine specimen as required by protocol",
    "recommendedFor": "Preventive healthcare & periodic screening",
    "mrp": 1000,
    "discountedPrice": 800,
    "discountPercent": 20
  },
  {
    "id": "pkg-63",
    "name": "AIIMS panel 1",
    "nameHi": "AIIMS panel 1",
    "type": "wellness",
    "targetAudience": "Adults, families, seniors & individuals seeking preventive screening",
    "targetAudienceHi": "वयस्क, वरिष्ठ नागरिक एवं नियमित स्वास्थ्य परीक्षण चाहने वाले",
    "price": "₹560",
    "isConfirmedPrice": true,
    "testsIncluded": [
      "AIIMS panel 1"
    ],
    "testsIncludedHi": [
      "AIIMS panel 1"
    ],
    "description": "Comprehensive diagnostic profile for AIIMS panel 1 conducted with clinical accuracy and 20% discount on standard MRP at Pawan Research Laboratory.",
    "descriptionHi": "पवन रिसर्च लैबोरेटरी में 20% एमआरपी छूट के साथ AIIMS panel 1 का संपूर्ण नैदानिक हेल्थ पैकेज।",
    "sampleRequired": "Blood & Urine specimen as required by protocol",
    "recommendedFor": "Preventive healthcare & periodic screening",
    "mrp": 700,
    "discountedPrice": 560,
    "discountPercent": 20
  },
  {
    "id": "pkg-64",
    "name": "AIIMS panel 2",
    "nameHi": "AIIMS panel 2",
    "type": "wellness",
    "targetAudience": "Adults, families, seniors & individuals seeking preventive screening",
    "targetAudienceHi": "वयस्क, वरिष्ठ नागरिक एवं नियमित स्वास्थ्य परीक्षण चाहने वाले",
    "price": "₹800",
    "isConfirmedPrice": true,
    "testsIncluded": [
      "AIIMS panel 2"
    ],
    "testsIncludedHi": [
      "AIIMS panel 2"
    ],
    "description": "Comprehensive diagnostic profile for AIIMS panel 2 conducted with clinical accuracy and 20% discount on standard MRP at Pawan Research Laboratory.",
    "descriptionHi": "पवन रिसर्च लैबोरेटरी में 20% एमआरपी छूट के साथ AIIMS panel 2 का संपूर्ण नैदानिक हेल्थ पैकेज।",
    "sampleRequired": "Blood & Urine specimen as required by protocol",
    "recommendedFor": "Preventive healthcare & periodic screening",
    "mrp": 1000,
    "discountedPrice": 800,
    "discountPercent": 20
  },
  {
    "id": "pkg-65",
    "name": "ANA PROFILE",
    "nameHi": "ANA PROFILE",
    "type": "wellness",
    "targetAudience": "Adults, families, seniors & individuals seeking preventive screening",
    "targetAudienceHi": "वयस्क, वरिष्ठ नागरिक एवं नियमित स्वास्थ्य परीक्षण चाहने वाले",
    "price": "₹3200",
    "isConfirmedPrice": true,
    "testsIncluded": [
      "ANA PROFILE"
    ],
    "testsIncludedHi": [
      "ANA PROFILE"
    ],
    "description": "Comprehensive diagnostic profile for ANA PROFILE conducted with clinical accuracy and 20% discount on standard MRP at Pawan Research Laboratory.",
    "descriptionHi": "पवन रिसर्च लैबोरेटरी में 20% एमआरपी छूट के साथ ANA PROFILE का संपूर्ण नैदानिक हेल्थ पैकेज।",
    "sampleRequired": "Blood & Urine specimen as required by protocol",
    "recommendedFor": "Preventive healthcare & periodic screening",
    "mrp": 4000,
    "discountedPrice": 3200,
    "discountPercent": 20
  },
  {
    "id": "pkg-66",
    "name": "CANCER PANEL (FEMALE)",
    "nameHi": "CANCER PANEL (FEMALE)",
    "type": "wellness",
    "targetAudience": "Adults, families, seniors & individuals seeking preventive screening",
    "targetAudienceHi": "वयस्क, वरिष्ठ नागरिक एवं नियमित स्वास्थ्य परीक्षण चाहने वाले",
    "price": "₹4000",
    "isConfirmedPrice": true,
    "testsIncluded": [
      "CANCER PANEL (FEMALE)"
    ],
    "testsIncludedHi": [
      "CANCER PANEL (FEMALE)"
    ],
    "description": "Comprehensive diagnostic profile for CANCER PANEL (FEMALE) conducted with clinical accuracy and 20% discount on standard MRP at Pawan Research Laboratory.",
    "descriptionHi": "पवन रिसर्च लैबोरेटरी में 20% एमआरपी छूट के साथ CANCER PANEL (FEMALE) का संपूर्ण नैदानिक हेल्थ पैकेज।",
    "sampleRequired": "Blood & Urine specimen as required by protocol",
    "recommendedFor": "Preventive healthcare & periodic screening",
    "mrp": 5000,
    "discountedPrice": 4000,
    "discountPercent": 20
  },
  {
    "id": "pkg-67",
    "name": "AMH GOLD",
    "nameHi": "AMH GOLD",
    "type": "wellness",
    "targetAudience": "Adults, families, seniors & individuals seeking preventive screening",
    "targetAudienceHi": "वयस्क, वरिष्ठ नागरिक एवं नियमित स्वास्थ्य परीक्षण चाहने वाले",
    "price": "₹2400",
    "isConfirmedPrice": true,
    "testsIncluded": [
      "AMH GOLD"
    ],
    "testsIncludedHi": [
      "AMH GOLD"
    ],
    "description": "Comprehensive diagnostic profile for AMH GOLD conducted with clinical accuracy and 20% discount on standard MRP at Pawan Research Laboratory.",
    "descriptionHi": "पवन रिसर्च लैबोरेटरी में 20% एमआरपी छूट के साथ AMH GOLD का संपूर्ण नैदानिक हेल्थ पैकेज।",
    "sampleRequired": "Blood & Urine specimen as required by protocol",
    "recommendedFor": "Preventive healthcare & periodic screening",
    "mrp": 3000,
    "discountedPrice": 2400,
    "discountPercent": 20
  },
  {
    "id": "pkg-68",
    "name": "AMH PLUS",
    "nameHi": "AMH PLUS",
    "type": "wellness",
    "targetAudience": "Adults, families, seniors & individuals seeking preventive screening",
    "targetAudienceHi": "वयस्क, वरिष्ठ नागरिक एवं नियमित स्वास्थ्य परीक्षण चाहने वाले",
    "price": "₹3200",
    "isConfirmedPrice": true,
    "testsIncluded": [
      "AMH PLUS"
    ],
    "testsIncludedHi": [
      "AMH PLUS"
    ],
    "description": "Comprehensive diagnostic profile for AMH PLUS conducted with clinical accuracy and 20% discount on standard MRP at Pawan Research Laboratory.",
    "descriptionHi": "पवन रिसर्च लैबोरेटरी में 20% एमआरपी छूट के साथ AMH PLUS का संपूर्ण नैदानिक हेल्थ पैकेज।",
    "sampleRequired": "Blood & Urine specimen as required by protocol",
    "recommendedFor": "Preventive healthcare & periodic screening",
    "mrp": 4000,
    "discountedPrice": 3200,
    "discountPercent": 20
  },
  {
    "id": "pkg-69",
    "name": "ANA PROFILE ELISA",
    "nameHi": "ANA PROFILE ELISA",
    "type": "wellness",
    "targetAudience": "Adults, families, seniors & individuals seeking preventive screening",
    "targetAudienceHi": "वयस्क, वरिष्ठ नागरिक एवं नियमित स्वास्थ्य परीक्षण चाहने वाले",
    "price": "₹3200",
    "isConfirmedPrice": true,
    "testsIncluded": [
      "ANA PROFILE ELISA"
    ],
    "testsIncludedHi": [
      "ANA PROFILE ELISA"
    ],
    "description": "Comprehensive diagnostic profile for ANA PROFILE ELISA conducted with clinical accuracy and 20% discount on standard MRP at Pawan Research Laboratory.",
    "descriptionHi": "पवन रिसर्च लैबोरेटरी में 20% एमआरपी छूट के साथ ANA PROFILE ELISA का संपूर्ण नैदानिक हेल्थ पैकेज।",
    "sampleRequired": "Blood & Urine specimen as required by protocol",
    "recommendedFor": "Preventive healthcare & periodic screening",
    "mrp": 4000,
    "discountedPrice": 3200,
    "discountPercent": 20
  },
  {
    "id": "pkg-70",
    "name": "GYNO-7",
    "nameHi": "GYNO-7",
    "type": "wellness",
    "targetAudience": "Adults, families, seniors & individuals seeking preventive screening",
    "targetAudienceHi": "वयस्क, वरिष्ठ नागरिक एवं नियमित स्वास्थ्य परीक्षण चाहने वाले",
    "price": "₹2560",
    "isConfirmedPrice": true,
    "testsIncluded": [
      "GYNO-7"
    ],
    "testsIncludedHi": [
      "GYNO-7"
    ],
    "description": "Comprehensive diagnostic profile for GYNO-7 conducted with clinical accuracy and 20% discount on standard MRP at Pawan Research Laboratory.",
    "descriptionHi": "पवन रिसर्च लैबोरेटरी में 20% एमआरपी छूट के साथ GYNO-7 का संपूर्ण नैदानिक हेल्थ पैकेज।",
    "sampleRequired": "Blood & Urine specimen as required by protocol",
    "recommendedFor": "Preventive healthcare & periodic screening",
    "mrp": 3200,
    "discountedPrice": 2560,
    "discountPercent": 20
  },
  {
    "id": "pkg-71",
    "name": "HEPATITIS B PROFILE",
    "nameHi": "HEPATITIS B PROFILE",
    "type": "wellness",
    "targetAudience": "Adults, families, seniors & individuals seeking preventive screening",
    "targetAudienceHi": "वयस्क, वरिष्ठ नागरिक एवं नियमित स्वास्थ्य परीक्षण चाहने वाले",
    "price": "₹4800",
    "isConfirmedPrice": true,
    "testsIncluded": [
      "HEPATITIS B PROFILE"
    ],
    "testsIncludedHi": [
      "HEPATITIS B PROFILE"
    ],
    "description": "Comprehensive diagnostic profile for HEPATITIS B PROFILE conducted with clinical accuracy and 20% discount on standard MRP at Pawan Research Laboratory.",
    "descriptionHi": "पवन रिसर्च लैबोरेटरी में 20% एमआरपी छूट के साथ HEPATITIS B PROFILE का संपूर्ण नैदानिक हेल्थ पैकेज।",
    "sampleRequired": "Blood & Urine specimen as required by protocol",
    "recommendedFor": "Preventive healthcare & periodic screening",
    "mrp": 6000,
    "discountedPrice": 4800,
    "discountPercent": 20
  },
  {
    "id": "pkg-72",
    "name": "HY AD WELLNESS - 1.3",
    "nameHi": "HY AD WELLNESS - 1.3",
    "type": "wellness",
    "targetAudience": "Adults, families, seniors & individuals seeking preventive screening",
    "targetAudienceHi": "वयस्क, वरिष्ठ नागरिक एवं नियमित स्वास्थ्य परीक्षण चाहने वाले",
    "price": "₹2560",
    "isConfirmedPrice": true,
    "testsIncluded": [
      "HY AD WELLNESS - 1.3"
    ],
    "testsIncludedHi": [
      "HY AD WELLNESS - 1.3"
    ],
    "description": "Comprehensive diagnostic profile for HY AD WELLNESS - 1.3 conducted with clinical accuracy and 20% discount on standard MRP at Pawan Research Laboratory.",
    "descriptionHi": "पवन रिसर्च लैबोरेटरी में 20% एमआरपी छूट के साथ HY AD WELLNESS - 1.3 का संपूर्ण नैदानिक हेल्थ पैकेज।",
    "sampleRequired": "Blood & Urine specimen as required by protocol",
    "recommendedFor": "Preventive healthcare & periodic screening",
    "mrp": 3200,
    "discountedPrice": 2560,
    "discountPercent": 20
  },
  {
    "id": "pkg-73",
    "name": "HY AD WELLNESS-1.2",
    "nameHi": "HY AD WELLNESS-1.2",
    "type": "wellness",
    "targetAudience": "Adults, families, seniors & individuals seeking preventive screening",
    "targetAudienceHi": "वयस्क, वरिष्ठ नागरिक एवं नियमित स्वास्थ्य परीक्षण चाहने वाले",
    "price": "₹1920",
    "isConfirmedPrice": true,
    "testsIncluded": [
      "HY AD WELLNESS-1.2"
    ],
    "testsIncludedHi": [
      "HY AD WELLNESS-1.2"
    ],
    "description": "Comprehensive diagnostic profile for HY AD WELLNESS-1.2 conducted with clinical accuracy and 20% discount on standard MRP at Pawan Research Laboratory.",
    "descriptionHi": "पवन रिसर्च लैबोरेटरी में 20% एमआरपी छूट के साथ HY AD WELLNESS-1.2 का संपूर्ण नैदानिक हेल्थ पैकेज।",
    "sampleRequired": "Blood & Urine specimen as required by protocol",
    "recommendedFor": "Preventive healthcare & periodic screening",
    "mrp": 2400,
    "discountedPrice": 1920,
    "discountPercent": 20
  },
  {
    "id": "pkg-74",
    "name": "Body (Maxi) Health Plan - Aarogya365 - 2 - HY",
    "nameHi": "Body (Maxi) Health Plan - Aarogya365 - 2 - HY",
    "type": "wellness",
    "targetAudience": "Adults, families, seniors & individuals seeking preventive screening",
    "targetAudienceHi": "वयस्क, वरिष्ठ नागरिक एवं नियमित स्वास्थ्य परीक्षण चाहने वाले",
    "price": "₹800",
    "isConfirmedPrice": true,
    "testsIncluded": [
      "Body (Maxi) Health Plan - Aarogya365 - 2 - HY"
    ],
    "testsIncludedHi": [
      "Body (Maxi) Health Plan - Aarogya365 - 2 - HY"
    ],
    "description": "Comprehensive diagnostic profile for Body (Maxi) Health Plan - Aarogya365 - 2 - HY conducted with clinical accuracy and 20% discount on standard MRP at Pawan Research Laboratory.",
    "descriptionHi": "पवन रिसर्च लैबोरेटरी में 20% एमआरपी छूट के साथ Body (Maxi) Health Plan - Aarogya365 - 2 - HY का संपूर्ण नैदानिक हेल्थ पैकेज।",
    "sampleRequired": "Blood & Urine specimen as required by protocol",
    "recommendedFor": "Preventive healthcare & periodic screening",
    "mrp": 1000,
    "discountedPrice": 800,
    "discountPercent": 20
  },
  {
    "id": "pkg-75",
    "name": "BODY (PLATINUM) HEALTH PLAN - MALE",
    "nameHi": "BODY (PLATINUM) HEALTH PLAN - MALE",
    "type": "wellness",
    "targetAudience": "Adults, families, seniors & individuals seeking preventive screening",
    "targetAudienceHi": "वयस्क, वरिष्ठ नागरिक एवं नियमित स्वास्थ्य परीक्षण चाहने वाले",
    "price": "₹3200",
    "isConfirmedPrice": true,
    "testsIncluded": [
      "BODY (PLATINUM) HEALTH PLAN - MALE"
    ],
    "testsIncludedHi": [
      "BODY (PLATINUM) HEALTH PLAN - MALE"
    ],
    "description": "Comprehensive diagnostic profile for BODY (PLATINUM) HEALTH PLAN - MALE conducted with clinical accuracy and 20% discount on standard MRP at Pawan Research Laboratory.",
    "descriptionHi": "पवन रिसर्च लैबोरेटरी में 20% एमआरपी छूट के साथ BODY (PLATINUM) HEALTH PLAN - MALE का संपूर्ण नैदानिक हेल्थ पैकेज।",
    "sampleRequired": "Blood & Urine specimen as required by protocol",
    "recommendedFor": "Preventive healthcare & periodic screening",
    "mrp": 4000,
    "discountedPrice": 3200,
    "discountPercent": 20
  },
  {
    "id": "pkg-76",
    "name": "BODY (PLATINUM) HEALTH PLAN - FEMALE",
    "nameHi": "BODY (PLATINUM) HEALTH PLAN - FEMALE",
    "type": "wellness",
    "targetAudience": "Adults, families, seniors & individuals seeking preventive screening",
    "targetAudienceHi": "वयस्क, वरिष्ठ नागरिक एवं नियमित स्वास्थ्य परीक्षण चाहने वाले",
    "price": "₹3200",
    "isConfirmedPrice": true,
    "testsIncluded": [
      "BODY (PLATINUM) HEALTH PLAN - FEMALE"
    ],
    "testsIncludedHi": [
      "BODY (PLATINUM) HEALTH PLAN - FEMALE"
    ],
    "description": "Comprehensive diagnostic profile for BODY (PLATINUM) HEALTH PLAN - FEMALE conducted with clinical accuracy and 20% discount on standard MRP at Pawan Research Laboratory.",
    "descriptionHi": "पवन रिसर्च लैबोरेटरी में 20% एमआरपी छूट के साथ BODY (PLATINUM) HEALTH PLAN - FEMALE का संपूर्ण नैदानिक हेल्थ पैकेज।",
    "sampleRequired": "Blood & Urine specimen as required by protocol",
    "recommendedFor": "Preventive healthcare & periodic screening",
    "mrp": 4000,
    "discountedPrice": 3200,
    "discountPercent": 20
  },
  {
    "id": "pkg-77",
    "name": "FAMILY PROFILE",
    "nameHi": "FAMILY PROFILE",
    "type": "wellness",
    "targetAudience": "Adults, families, seniors & individuals seeking preventive screening",
    "targetAudienceHi": "वयस्क, वरिष्ठ नागरिक एवं नियमित स्वास्थ्य परीक्षण चाहने वाले",
    "price": "₹720",
    "isConfirmedPrice": true,
    "testsIncluded": [
      "FAMILY PROFILE"
    ],
    "testsIncludedHi": [
      "FAMILY PROFILE"
    ],
    "description": "Comprehensive diagnostic profile for FAMILY PROFILE conducted with clinical accuracy and 20% discount on standard MRP at Pawan Research Laboratory.",
    "descriptionHi": "पवन रिसर्च लैबोरेटरी में 20% एमआरपी छूट के साथ FAMILY PROFILE का संपूर्ण नैदानिक हेल्थ पैकेज।",
    "sampleRequired": "Blood & Urine specimen as required by protocol",
    "recommendedFor": "Preventive healthcare & periodic screening",
    "mrp": 900,
    "discountedPrice": 720,
    "discountPercent": 20
  },
  {
    "id": "pkg-78",
    "name": "PRE HEALTH",
    "nameHi": "PRE HEALTH",
    "type": "wellness",
    "targetAudience": "Adults, families, seniors & individuals seeking preventive screening",
    "targetAudienceHi": "वयस्क, वरिष्ठ नागरिक एवं नियमित स्वास्थ्य परीक्षण चाहने वाले",
    "price": "₹800",
    "isConfirmedPrice": true,
    "testsIncluded": [
      "PRE HEALTH"
    ],
    "testsIncludedHi": [
      "PRE HEALTH"
    ],
    "description": "Comprehensive diagnostic profile for PRE HEALTH conducted with clinical accuracy and 20% discount on standard MRP at Pawan Research Laboratory.",
    "descriptionHi": "पवन रिसर्च लैबोरेटरी में 20% एमआरपी छूट के साथ PRE HEALTH का संपूर्ण नैदानिक हेल्थ पैकेज।",
    "sampleRequired": "Blood & Urine specimen as required by protocol",
    "recommendedFor": "Preventive healthcare & periodic screening",
    "mrp": 1000,
    "discountedPrice": 800,
    "discountPercent": 20
  },
  {
    "id": "pkg-79",
    "name": "HY FLUID-1",
    "nameHi": "HY FLUID-1",
    "type": "wellness",
    "targetAudience": "Adults, families, seniors & individuals seeking preventive screening",
    "targetAudienceHi": "वयस्क, वरिष्ठ नागरिक एवं नियमित स्वास्थ्य परीक्षण चाहने वाले",
    "price": "₹800",
    "isConfirmedPrice": true,
    "testsIncluded": [
      "HY FLUID-1"
    ],
    "testsIncludedHi": [
      "HY FLUID-1"
    ],
    "description": "Comprehensive diagnostic profile for HY FLUID-1 conducted with clinical accuracy and 20% discount on standard MRP at Pawan Research Laboratory.",
    "descriptionHi": "पवन रिसर्च लैबोरेटरी में 20% एमआरपी छूट के साथ HY FLUID-1 का संपूर्ण नैदानिक हेल्थ पैकेज।",
    "sampleRequired": "Blood & Urine specimen as required by protocol",
    "recommendedFor": "Preventive healthcare & periodic screening",
    "mrp": 1000,
    "discountedPrice": 800,
    "discountPercent": 20
  },
  {
    "id": "pkg-80",
    "name": "HY coagulation profile -1",
    "nameHi": "HY coagulation profile -1",
    "type": "wellness",
    "targetAudience": "Adults, families, seniors & individuals seeking preventive screening",
    "targetAudienceHi": "वयस्क, वरिष्ठ नागरिक एवं नियमित स्वास्थ्य परीक्षण चाहने वाले",
    "price": "₹1360",
    "isConfirmedPrice": true,
    "testsIncluded": [
      "HY coagulation profile -1"
    ],
    "testsIncludedHi": [
      "HY coagulation profile -1"
    ],
    "description": "Comprehensive diagnostic profile for HY coagulation profile -1 conducted with clinical accuracy and 20% discount on standard MRP at Pawan Research Laboratory.",
    "descriptionHi": "पवन रिसर्च लैबोरेटरी में 20% एमआरपी छूट के साथ HY coagulation profile -1 का संपूर्ण नैदानिक हेल्थ पैकेज।",
    "sampleRequired": "Blood & Urine specimen as required by protocol",
    "recommendedFor": "Preventive healthcare & periodic screening",
    "mrp": 1700,
    "discountedPrice": 1360,
    "discountPercent": 20
  },
  {
    "id": "pkg-81",
    "name": "CARDIAC PROFILE - M",
    "nameHi": "CARDIAC PROFILE - M",
    "type": "wellness",
    "targetAudience": "Adults, families, seniors & individuals seeking preventive screening",
    "targetAudienceHi": "वयस्क, वरिष्ठ नागरिक एवं नियमित स्वास्थ्य परीक्षण चाहने वाले",
    "price": "₹2000",
    "isConfirmedPrice": true,
    "testsIncluded": [
      "CARDIAC PROFILE - M"
    ],
    "testsIncludedHi": [
      "CARDIAC PROFILE - M"
    ],
    "description": "Comprehensive diagnostic profile for CARDIAC PROFILE - M conducted with clinical accuracy and 20% discount on standard MRP at Pawan Research Laboratory.",
    "descriptionHi": "पवन रिसर्च लैबोरेटरी में 20% एमआरपी छूट के साथ CARDIAC PROFILE - M का संपूर्ण नैदानिक हेल्थ पैकेज।",
    "sampleRequired": "Blood & Urine specimen as required by protocol",
    "recommendedFor": "Preventive healthcare & periodic screening",
    "mrp": 2500,
    "discountedPrice": 2000,
    "discountPercent": 20
  },
  {
    "id": "pkg-82",
    "name": "CARDIAC RISK MARKERS",
    "nameHi": "CARDIAC RISK MARKERS",
    "type": "wellness",
    "targetAudience": "Adults, families, seniors & individuals seeking preventive screening",
    "targetAudienceHi": "वयस्क, वरिष्ठ नागरिक एवं नियमित स्वास्थ्य परीक्षण चाहने वाले",
    "price": "₹480",
    "isConfirmedPrice": true,
    "testsIncluded": [
      "CARDIAC RISK MARKERS"
    ],
    "testsIncludedHi": [
      "CARDIAC RISK MARKERS"
    ],
    "description": "Comprehensive diagnostic profile for CARDIAC RISK MARKERS conducted with clinical accuracy and 20% discount on standard MRP at Pawan Research Laboratory.",
    "descriptionHi": "पवन रिसर्च लैबोरेटरी में 20% एमआरपी छूट के साथ CARDIAC RISK MARKERS का संपूर्ण नैदानिक हेल्थ पैकेज।",
    "sampleRequired": "Blood & Urine specimen as required by protocol",
    "recommendedFor": "Preventive healthcare & periodic screening",
    "mrp": 600,
    "discountedPrice": 480,
    "discountPercent": 20
  },
  {
    "id": "pkg-83",
    "name": "CARDIAC PROFILE - C",
    "nameHi": "CARDIAC PROFILE - C",
    "type": "wellness",
    "targetAudience": "Adults, families, seniors & individuals seeking preventive screening",
    "targetAudienceHi": "वयस्क, वरिष्ठ नागरिक एवं नियमित स्वास्थ्य परीक्षण चाहने वाले",
    "price": "₹5600",
    "isConfirmedPrice": true,
    "testsIncluded": [
      "CARDIAC PROFILE - C"
    ],
    "testsIncludedHi": [
      "CARDIAC PROFILE - C"
    ],
    "description": "Comprehensive diagnostic profile for CARDIAC PROFILE - C conducted with clinical accuracy and 20% discount on standard MRP at Pawan Research Laboratory.",
    "descriptionHi": "पवन रिसर्च लैबोरेटरी में 20% एमआरपी छूट के साथ CARDIAC PROFILE - C का संपूर्ण नैदानिक हेल्थ पैकेज।",
    "sampleRequired": "Blood & Urine specimen as required by protocol",
    "recommendedFor": "Preventive healthcare & periodic screening",
    "mrp": 7000,
    "discountedPrice": 5600,
    "discountPercent": 20
  },
  {
    "id": "pkg-84",
    "name": "CARDIAC PROFILE - B",
    "nameHi": "CARDIAC PROFILE - B",
    "type": "wellness",
    "targetAudience": "Adults, families, seniors & individuals seeking preventive screening",
    "targetAudienceHi": "वयस्क, वरिष्ठ नागरिक एवं नियमित स्वास्थ्य परीक्षण चाहने वाले",
    "price": "₹4000",
    "isConfirmedPrice": true,
    "testsIncluded": [
      "CARDIAC PROFILE - B"
    ],
    "testsIncludedHi": [
      "CARDIAC PROFILE - B"
    ],
    "description": "Comprehensive diagnostic profile for CARDIAC PROFILE - B conducted with clinical accuracy and 20% discount on standard MRP at Pawan Research Laboratory.",
    "descriptionHi": "पवन रिसर्च लैबोरेटरी में 20% एमआरपी छूट के साथ CARDIAC PROFILE - B का संपूर्ण नैदानिक हेल्थ पैकेज।",
    "sampleRequired": "Blood & Urine specimen as required by protocol",
    "recommendedFor": "Preventive healthcare & periodic screening",
    "mrp": 5000,
    "discountedPrice": 4000,
    "discountPercent": 20
  },
  {
    "id": "pkg-85",
    "name": "CARDIAC PROFILE - A",
    "nameHi": "CARDIAC PROFILE - A",
    "type": "wellness",
    "targetAudience": "Adults, families, seniors & individuals seeking preventive screening",
    "targetAudienceHi": "वयस्क, वरिष्ठ नागरिक एवं नियमित स्वास्थ्य परीक्षण चाहने वाले",
    "price": "₹3200",
    "isConfirmedPrice": true,
    "testsIncluded": [
      "CARDIAC PROFILE - A"
    ],
    "testsIncludedHi": [
      "CARDIAC PROFILE - A"
    ],
    "description": "Comprehensive diagnostic profile for CARDIAC PROFILE - A conducted with clinical accuracy and 20% discount on standard MRP at Pawan Research Laboratory.",
    "descriptionHi": "पवन रिसर्च लैबोरेटरी में 20% एमआरपी छूट के साथ CARDIAC PROFILE - A का संपूर्ण नैदानिक हेल्थ पैकेज।",
    "sampleRequired": "Blood & Urine specimen as required by protocol",
    "recommendedFor": "Preventive healthcare & periodic screening",
    "mrp": 4000,
    "discountedPrice": 3200,
    "discountPercent": 20
  },
  {
    "id": "pkg-86",
    "name": "CARDIAC PANEL - II",
    "nameHi": "CARDIAC PANEL - II",
    "type": "wellness",
    "targetAudience": "Adults, families, seniors & individuals seeking preventive screening",
    "targetAudienceHi": "वयस्क, वरिष्ठ नागरिक एवं नियमित स्वास्थ्य परीक्षण चाहने वाले",
    "price": "₹4000",
    "isConfirmedPrice": true,
    "testsIncluded": [
      "CARDIAC PANEL - II"
    ],
    "testsIncludedHi": [
      "CARDIAC PANEL - II"
    ],
    "description": "Comprehensive diagnostic profile for CARDIAC PANEL - II conducted with clinical accuracy and 20% discount on standard MRP at Pawan Research Laboratory.",
    "descriptionHi": "पवन रिसर्च लैबोरेटरी में 20% एमआरपी छूट के साथ CARDIAC PANEL - II का संपूर्ण नैदानिक हेल्थ पैकेज।",
    "sampleRequired": "Blood & Urine specimen as required by protocol",
    "recommendedFor": "Preventive healthcare & periodic screening",
    "mrp": 5000,
    "discountedPrice": 4000,
    "discountPercent": 20
  },
  {
    "id": "pkg-87",
    "name": "CARDIAC PANEL - I",
    "nameHi": "CARDIAC PANEL - I",
    "type": "wellness",
    "targetAudience": "Adults, families, seniors & individuals seeking preventive screening",
    "targetAudienceHi": "वयस्क, वरिष्ठ नागरिक एवं नियमित स्वास्थ्य परीक्षण चाहने वाले",
    "price": "₹880",
    "isConfirmedPrice": true,
    "testsIncluded": [
      "CARDIAC PANEL - I"
    ],
    "testsIncludedHi": [
      "CARDIAC PANEL - I"
    ],
    "description": "Comprehensive diagnostic profile for CARDIAC PANEL - I conducted with clinical accuracy and 20% discount on standard MRP at Pawan Research Laboratory.",
    "descriptionHi": "पवन रिसर्च लैबोरेटरी में 20% एमआरपी छूट के साथ CARDIAC PANEL - I का संपूर्ण नैदानिक हेल्थ पैकेज।",
    "sampleRequired": "Blood & Urine specimen as required by protocol",
    "recommendedFor": "Preventive healthcare & periodic screening",
    "mrp": 1100,
    "discountedPrice": 880,
    "discountPercent": 20
  },
  {
    "id": "pkg-88",
    "name": "AMH PLUS",
    "nameHi": "AMH PLUS",
    "type": "wellness",
    "targetAudience": "Adults, families, seniors & individuals seeking preventive screening",
    "targetAudienceHi": "वयस्क, वरिष्ठ नागरिक एवं नियमित स्वास्थ्य परीक्षण चाहने वाले",
    "price": "₹4000",
    "isConfirmedPrice": true,
    "testsIncluded": [
      "AMH PLUS"
    ],
    "testsIncludedHi": [
      "AMH PLUS"
    ],
    "description": "Comprehensive diagnostic profile for AMH PLUS conducted with clinical accuracy and 20% discount on standard MRP at Pawan Research Laboratory.",
    "descriptionHi": "पवन रिसर्च लैबोरेटरी में 20% एमआरपी छूट के साथ AMH PLUS का संपूर्ण नैदानिक हेल्थ पैकेज।",
    "sampleRequired": "Blood & Urine specimen as required by protocol",
    "recommendedFor": "Preventive healthcare & periodic screening",
    "mrp": 5000,
    "discountedPrice": 4000,
    "discountPercent": 20
  },
  {
    "id": "pkg-89",
    "name": "THALASSEMIA SCREEN",
    "nameHi": "THALASSEMIA SCREEN",
    "type": "wellness",
    "targetAudience": "Adults, families, seniors & individuals seeking preventive screening",
    "targetAudienceHi": "वयस्क, वरिष्ठ नागरिक एवं नियमित स्वास्थ्य परीक्षण चाहने वाले",
    "price": "₹1600",
    "isConfirmedPrice": true,
    "testsIncluded": [
      "THALASSEMIA SCREEN"
    ],
    "testsIncludedHi": [
      "THALASSEMIA SCREEN"
    ],
    "description": "Comprehensive diagnostic profile for THALASSEMIA SCREEN conducted with clinical accuracy and 20% discount on standard MRP at Pawan Research Laboratory.",
    "descriptionHi": "पवन रिसर्च लैबोरेटरी में 20% एमआरपी छूट के साथ THALASSEMIA SCREEN का संपूर्ण नैदानिक हेल्थ पैकेज।",
    "sampleRequired": "Blood & Urine specimen as required by protocol",
    "recommendedFor": "Preventive healthcare & periodic screening",
    "mrp": 2000,
    "discountedPrice": 1600,
    "discountPercent": 20
  },
  {
    "id": "pkg-90",
    "name": "THALASSEMIA PROFILE",
    "nameHi": "THALASSEMIA PROFILE",
    "type": "wellness",
    "targetAudience": "Adults, families, seniors & individuals seeking preventive screening",
    "targetAudienceHi": "वयस्क, वरिष्ठ नागरिक एवं नियमित स्वास्थ्य परीक्षण चाहने वाले",
    "price": "₹2880",
    "isConfirmedPrice": true,
    "testsIncluded": [
      "THALASSEMIA PROFILE"
    ],
    "testsIncludedHi": [
      "THALASSEMIA PROFILE"
    ],
    "description": "Comprehensive diagnostic profile for THALASSEMIA PROFILE conducted with clinical accuracy and 20% discount on standard MRP at Pawan Research Laboratory.",
    "descriptionHi": "पवन रिसर्च लैबोरेटरी में 20% एमआरपी छूट के साथ THALASSEMIA PROFILE का संपूर्ण नैदानिक हेल्थ पैकेज।",
    "sampleRequired": "Blood & Urine specimen as required by protocol",
    "recommendedFor": "Preventive healthcare & periodic screening",
    "mrp": 3600,
    "discountedPrice": 2880,
    "discountPercent": 20
  },
  {
    "id": "pkg-91",
    "name": "ANEMIA PROFILE - M",
    "nameHi": "ANEMIA PROFILE - M",
    "type": "wellness",
    "targetAudience": "Adults, families, seniors & individuals seeking preventive screening",
    "targetAudienceHi": "वयस्क, वरिष्ठ नागरिक एवं नियमित स्वास्थ्य परीक्षण चाहने वाले",
    "price": "₹1056",
    "isConfirmedPrice": true,
    "testsIncluded": [
      "ANEMIA PROFILE - M"
    ],
    "testsIncludedHi": [
      "ANEMIA PROFILE - M"
    ],
    "description": "Comprehensive diagnostic profile for ANEMIA PROFILE - M conducted with clinical accuracy and 20% discount on standard MRP at Pawan Research Laboratory.",
    "descriptionHi": "पवन रिसर्च लैबोरेटरी में 20% एमआरपी छूट के साथ ANEMIA PROFILE - M का संपूर्ण नैदानिक हेल्थ पैकेज।",
    "sampleRequired": "Blood & Urine specimen as required by protocol",
    "recommendedFor": "Preventive healthcare & periodic screening",
    "mrp": 1320,
    "discountedPrice": 1056,
    "discountPercent": 20
  },
  {
    "id": "pkg-92",
    "name": "ANEMIA PROFILE II",
    "nameHi": "ANEMIA PROFILE II",
    "type": "wellness",
    "targetAudience": "Adults, families, seniors & individuals seeking preventive screening",
    "targetAudienceHi": "वयस्क, वरिष्ठ नागरिक एवं नियमित स्वास्थ्य परीक्षण चाहने वाले",
    "price": "₹792",
    "isConfirmedPrice": true,
    "testsIncluded": [
      "ANEMIA PROFILE II"
    ],
    "testsIncludedHi": [
      "ANEMIA PROFILE II"
    ],
    "description": "Comprehensive diagnostic profile for ANEMIA PROFILE II conducted with clinical accuracy and 20% discount on standard MRP at Pawan Research Laboratory.",
    "descriptionHi": "पवन रिसर्च लैबोरेटरी में 20% एमआरपी छूट के साथ ANEMIA PROFILE II का संपूर्ण नैदानिक हेल्थ पैकेज।",
    "sampleRequired": "Blood & Urine specimen as required by protocol",
    "recommendedFor": "Preventive healthcare & periodic screening",
    "mrp": 990,
    "discountedPrice": 792,
    "discountPercent": 20
  },
  {
    "id": "pkg-93",
    "name": "ANEMIA STUDY",
    "nameHi": "ANEMIA STUDY",
    "type": "wellness",
    "targetAudience": "Adults, families, seniors & individuals seeking preventive screening",
    "targetAudienceHi": "वयस्क, वरिष्ठ नागरिक एवं नियमित स्वास्थ्य परीक्षण चाहने वाले",
    "price": "₹9696",
    "isConfirmedPrice": true,
    "testsIncluded": [
      "ANEMIA STUDY"
    ],
    "testsIncludedHi": [
      "ANEMIA STUDY"
    ],
    "description": "Comprehensive diagnostic profile for ANEMIA STUDY conducted with clinical accuracy and 20% discount on standard MRP at Pawan Research Laboratory.",
    "descriptionHi": "पवन रिसर्च लैबोरेटरी में 20% एमआरपी छूट के साथ ANEMIA STUDY का संपूर्ण नैदानिक हेल्थ पैकेज।",
    "sampleRequired": "Blood & Urine specimen as required by protocol",
    "recommendedFor": "Preventive healthcare & periodic screening",
    "mrp": 12121,
    "discountedPrice": 9696,
    "discountPercent": 20
  },
  {
    "id": "pkg-94",
    "name": "ANEMIA PROFILE - A",
    "nameHi": "ANEMIA PROFILE - A",
    "type": "wellness",
    "targetAudience": "Adults, families, seniors & individuals seeking preventive screening",
    "targetAudienceHi": "वयस्क, वरिष्ठ नागरिक एवं नियमित स्वास्थ्य परीक्षण चाहने वाले",
    "price": "₹1496",
    "isConfirmedPrice": true,
    "testsIncluded": [
      "ANEMIA PROFILE - A"
    ],
    "testsIncludedHi": [
      "ANEMIA PROFILE - A"
    ],
    "description": "Comprehensive diagnostic profile for ANEMIA PROFILE - A conducted with clinical accuracy and 20% discount on standard MRP at Pawan Research Laboratory.",
    "descriptionHi": "पवन रिसर्च लैबोरेटरी में 20% एमआरपी छूट के साथ ANEMIA PROFILE - A का संपूर्ण नैदानिक हेल्थ पैकेज।",
    "sampleRequired": "Blood & Urine specimen as required by protocol",
    "recommendedFor": "Preventive healthcare & periodic screening",
    "mrp": 1870,
    "discountedPrice": 1496,
    "discountPercent": 20
  },
  {
    "id": "pkg-95",
    "name": "Anemia Profile - Aarogya365 - 2 - HY",
    "nameHi": "Anemia Profile - Aarogya365 - 2 - HY",
    "type": "wellness",
    "targetAudience": "Adults, families, seniors & individuals seeking preventive screening",
    "targetAudienceHi": "वयस्क, वरिष्ठ नागरिक एवं नियमित स्वास्थ्य परीक्षण चाहने वाले",
    "price": "₹9696",
    "isConfirmedPrice": true,
    "testsIncluded": [
      "Anemia Profile - Aarogya365 - 2 - HY"
    ],
    "testsIncludedHi": [
      "Anemia Profile - Aarogya365 - 2 - HY"
    ],
    "description": "Comprehensive diagnostic profile for Anemia Profile - Aarogya365 - 2 - HY conducted with clinical accuracy and 20% discount on standard MRP at Pawan Research Laboratory.",
    "descriptionHi": "पवन रिसर्च लैबोरेटरी में 20% एमआरपी छूट के साथ Anemia Profile - Aarogya365 - 2 - HY का संपूर्ण नैदानिक हेल्थ पैकेज।",
    "sampleRequired": "Blood & Urine specimen as required by protocol",
    "recommendedFor": "Preventive healthcare & periodic screening",
    "mrp": 12121,
    "discountedPrice": 9696,
    "discountPercent": 20
  },
  {
    "id": "pkg-96",
    "name": "ANEMIA PROFILE - B",
    "nameHi": "ANEMIA PROFILE - B",
    "type": "wellness",
    "targetAudience": "Adults, families, seniors & individuals seeking preventive screening",
    "targetAudienceHi": "वयस्क, वरिष्ठ नागरिक एवं नियमित स्वास्थ्य परीक्षण चाहने वाले",
    "price": "₹1936",
    "isConfirmedPrice": true,
    "testsIncluded": [
      "ANEMIA PROFILE - B"
    ],
    "testsIncludedHi": [
      "ANEMIA PROFILE - B"
    ],
    "description": "Comprehensive diagnostic profile for ANEMIA PROFILE - B conducted with clinical accuracy and 20% discount on standard MRP at Pawan Research Laboratory.",
    "descriptionHi": "पवन रिसर्च लैबोरेटरी में 20% एमआरपी छूट के साथ ANEMIA PROFILE - B का संपूर्ण नैदानिक हेल्थ पैकेज।",
    "sampleRequired": "Blood & Urine specimen as required by protocol",
    "recommendedFor": "Preventive healthcare & periodic screening",
    "mrp": 2420,
    "discountedPrice": 1936,
    "discountPercent": 20
  },
  {
    "id": "pkg-97",
    "name": "ANEMIA PROFILE - C",
    "nameHi": "ANEMIA PROFILE - C",
    "type": "wellness",
    "targetAudience": "Adults, families, seniors & individuals seeking preventive screening",
    "targetAudienceHi": "वयस्क, वरिष्ठ नागरिक एवं नियमित स्वास्थ्य परीक्षण चाहने वाले",
    "price": "₹2112",
    "isConfirmedPrice": true,
    "testsIncluded": [
      "ANEMIA PROFILE - C"
    ],
    "testsIncludedHi": [
      "ANEMIA PROFILE - C"
    ],
    "description": "Comprehensive diagnostic profile for ANEMIA PROFILE - C conducted with clinical accuracy and 20% discount on standard MRP at Pawan Research Laboratory.",
    "descriptionHi": "पवन रिसर्च लैबोरेटरी में 20% एमआरपी छूट के साथ ANEMIA PROFILE - C का संपूर्ण नैदानिक हेल्थ पैकेज।",
    "sampleRequired": "Blood & Urine specimen as required by protocol",
    "recommendedFor": "Preventive healthcare & periodic screening",
    "mrp": 2640,
    "discountedPrice": 2112,
    "discountPercent": 20
  },
  {
    "id": "pkg-98",
    "name": "ANEMIA PROFILE - I",
    "nameHi": "ANEMIA PROFILE - I",
    "type": "wellness",
    "targetAudience": "Adults, families, seniors & individuals seeking preventive screening",
    "targetAudienceHi": "वयस्क, वरिष्ठ नागरिक एवं नियमित स्वास्थ्य परीक्षण चाहने वाले",
    "price": "₹704",
    "isConfirmedPrice": true,
    "testsIncluded": [
      "ANEMIA PROFILE - I"
    ],
    "testsIncludedHi": [
      "ANEMIA PROFILE - I"
    ],
    "description": "Comprehensive diagnostic profile for ANEMIA PROFILE - I conducted with clinical accuracy and 20% discount on standard MRP at Pawan Research Laboratory.",
    "descriptionHi": "पवन रिसर्च लैबोरेटरी में 20% एमआरपी छूट के साथ ANEMIA PROFILE - I का संपूर्ण नैदानिक हेल्थ पैकेज।",
    "sampleRequired": "Blood & Urine specimen as required by protocol",
    "recommendedFor": "Preventive healthcare & periodic screening",
    "mrp": 880,
    "discountedPrice": 704,
    "discountPercent": 20
  },
  {
    "id": "pkg-99",
    "name": "ANEMIA PROFILE - III",
    "nameHi": "ANEMIA PROFILE - III",
    "type": "wellness",
    "targetAudience": "Adults, families, seniors & individuals seeking preventive screening",
    "targetAudienceHi": "वयस्क, वरिष्ठ नागरिक एवं नियमित स्वास्थ्य परीक्षण चाहने वाले",
    "price": "₹1372",
    "isConfirmedPrice": true,
    "testsIncluded": [
      "ANEMIA PROFILE - III"
    ],
    "testsIncludedHi": [
      "ANEMIA PROFILE - III"
    ],
    "description": "Comprehensive diagnostic profile for ANEMIA PROFILE - III conducted with clinical accuracy and 20% discount on standard MRP at Pawan Research Laboratory.",
    "descriptionHi": "पवन रिसर्च लैबोरेटरी में 20% एमआरपी छूट के साथ ANEMIA PROFILE - III का संपूर्ण नैदानिक हेल्थ पैकेज।",
    "sampleRequired": "Blood & Urine specimen as required by protocol",
    "recommendedFor": "Preventive healthcare & periodic screening",
    "mrp": 1716,
    "discountedPrice": 1372,
    "discountPercent": 20
  },
  {
    "id": "pkg-100",
    "name": "ALLERGY PANEL II",
    "nameHi": "ALLERGY PANEL II",
    "type": "wellness",
    "targetAudience": "Adults, families, seniors & individuals seeking preventive screening",
    "targetAudienceHi": "वयस्क, वरिष्ठ नागरिक एवं नियमित स्वास्थ्य परीक्षण चाहने वाले",
    "price": "₹620",
    "isConfirmedPrice": true,
    "testsIncluded": [
      "ALLERGY PANEL II"
    ],
    "testsIncludedHi": [
      "ALLERGY PANEL II"
    ],
    "description": "Comprehensive diagnostic profile for ALLERGY PANEL II conducted with clinical accuracy and 20% discount on standard MRP at Pawan Research Laboratory.",
    "descriptionHi": "पवन रिसर्च लैबोरेटरी में 20% एमआरपी छूट के साथ ALLERGY PANEL II का संपूर्ण नैदानिक हेल्थ पैकेज।",
    "sampleRequired": "Blood & Urine specimen as required by protocol",
    "recommendedFor": "Preventive healthcare & periodic screening",
    "mrp": 776,
    "discountedPrice": 620,
    "discountPercent": 20
  },
  {
    "id": "pkg-101",
    "name": "HAIRFALL PROFIE",
    "nameHi": "HAIRFALL PROFIE",
    "type": "wellness",
    "targetAudience": "Adults, families, seniors & individuals seeking preventive screening",
    "targetAudienceHi": "वयस्क, वरिष्ठ नागरिक एवं नियमित स्वास्थ्य परीक्षण चाहने वाले",
    "price": "₹4000",
    "isConfirmedPrice": true,
    "testsIncluded": [
      "HAIRFALL PROFIE"
    ],
    "testsIncludedHi": [
      "HAIRFALL PROFIE"
    ],
    "description": "Comprehensive diagnostic profile for HAIRFALL PROFIE conducted with clinical accuracy and 20% discount on standard MRP at Pawan Research Laboratory.",
    "descriptionHi": "पवन रिसर्च लैबोरेटरी में 20% एमआरपी छूट के साथ HAIRFALL PROFIE का संपूर्ण नैदानिक हेल्थ पैकेज।",
    "sampleRequired": "Blood & Urine specimen as required by protocol",
    "recommendedFor": "Preventive healthcare & periodic screening",
    "mrp": 5000,
    "discountedPrice": 4000,
    "discountPercent": 20
  },
  {
    "id": "pkg-102",
    "name": "DIABETIC PANEL - MINI",
    "nameHi": "DIABETIC PANEL - MINI",
    "type": "wellness",
    "targetAudience": "Adults, families, seniors & individuals seeking preventive screening",
    "targetAudienceHi": "वयस्क, वरिष्ठ नागरिक एवं नियमित स्वास्थ्य परीक्षण चाहने वाले",
    "price": "₹560",
    "isConfirmedPrice": true,
    "testsIncluded": [
      "DIABETIC PANEL - MINI"
    ],
    "testsIncludedHi": [
      "DIABETIC PANEL - MINI"
    ],
    "description": "Comprehensive diagnostic profile for DIABETIC PANEL - MINI conducted with clinical accuracy and 20% discount on standard MRP at Pawan Research Laboratory.",
    "descriptionHi": "पवन रिसर्च लैबोरेटरी में 20% एमआरपी छूट के साथ DIABETIC PANEL - MINI का संपूर्ण नैदानिक हेल्थ पैकेज।",
    "sampleRequired": "Blood & Urine specimen as required by protocol",
    "recommendedFor": "Preventive healthcare & periodic screening",
    "mrp": 700,
    "discountedPrice": 560,
    "discountPercent": 20
  },
  {
    "id": "pkg-103",
    "name": "DIABETIC PROFILE - A",
    "nameHi": "DIABETIC PROFILE - A",
    "type": "wellness",
    "targetAudience": "Adults, families, seniors & individuals seeking preventive screening",
    "targetAudienceHi": "वयस्क, वरिष्ठ नागरिक एवं नियमित स्वास्थ्य परीक्षण चाहने वाले",
    "price": "₹2160",
    "isConfirmedPrice": true,
    "testsIncluded": [
      "DIABETIC PROFILE - A"
    ],
    "testsIncludedHi": [
      "DIABETIC PROFILE - A"
    ],
    "description": "Comprehensive diagnostic profile for DIABETIC PROFILE - A conducted with clinical accuracy and 20% discount on standard MRP at Pawan Research Laboratory.",
    "descriptionHi": "पवन रिसर्च लैबोरेटरी में 20% एमआरपी छूट के साथ DIABETIC PROFILE - A का संपूर्ण नैदानिक हेल्थ पैकेज।",
    "sampleRequired": "Blood & Urine specimen as required by protocol",
    "recommendedFor": "Preventive healthcare & periodic screening",
    "mrp": 2700,
    "discountedPrice": 2160,
    "discountPercent": 20
  },
  {
    "id": "pkg-104",
    "name": "DIABETIC PROFILE - B",
    "nameHi": "DIABETIC PROFILE - B",
    "type": "wellness",
    "targetAudience": "Adults, families, seniors & individuals seeking preventive screening",
    "targetAudienceHi": "वयस्क, वरिष्ठ नागरिक एवं नियमित स्वास्थ्य परीक्षण चाहने वाले",
    "price": "₹2200",
    "isConfirmedPrice": true,
    "testsIncluded": [
      "DIABETIC PROFILE - B"
    ],
    "testsIncludedHi": [
      "DIABETIC PROFILE - B"
    ],
    "description": "Comprehensive diagnostic profile for DIABETIC PROFILE - B conducted with clinical accuracy and 20% discount on standard MRP at Pawan Research Laboratory.",
    "descriptionHi": "पवन रिसर्च लैबोरेटरी में 20% एमआरपी छूट के साथ DIABETIC PROFILE - B का संपूर्ण नैदानिक हेल्थ पैकेज।",
    "sampleRequired": "Blood & Urine specimen as required by protocol",
    "recommendedFor": "Preventive healthcare & periodic screening",
    "mrp": 2750,
    "discountedPrice": 2200,
    "discountPercent": 20
  },
  {
    "id": "pkg-105",
    "name": "DIABETIC PROFILE - C",
    "nameHi": "DIABETIC PROFILE - C",
    "type": "wellness",
    "targetAudience": "Adults, families, seniors & individuals seeking preventive screening",
    "targetAudienceHi": "वयस्क, वरिष्ठ नागरिक एवं नियमित स्वास्थ्य परीक्षण चाहने वाले",
    "price": "₹2560",
    "isConfirmedPrice": true,
    "testsIncluded": [
      "DIABETIC PROFILE - C"
    ],
    "testsIncludedHi": [
      "DIABETIC PROFILE - C"
    ],
    "description": "Comprehensive diagnostic profile for DIABETIC PROFILE - C conducted with clinical accuracy and 20% discount on standard MRP at Pawan Research Laboratory.",
    "descriptionHi": "पवन रिसर्च लैबोरेटरी में 20% एमआरपी छूट के साथ DIABETIC PROFILE - C का संपूर्ण नैदानिक हेल्थ पैकेज।",
    "sampleRequired": "Blood & Urine specimen as required by protocol",
    "recommendedFor": "Preventive healthcare & periodic screening",
    "mrp": 3200,
    "discountedPrice": 2560,
    "discountPercent": 20
  },
  {
    "id": "pkg-106",
    "name": "DIABETIC PROFILE - M",
    "nameHi": "DIABETIC PROFILE - M",
    "type": "wellness",
    "targetAudience": "Adults, families, seniors & individuals seeking preventive screening",
    "targetAudienceHi": "वयस्क, वरिष्ठ नागरिक एवं नियमित स्वास्थ्य परीक्षण चाहने वाले",
    "price": "₹1120",
    "isConfirmedPrice": true,
    "testsIncluded": [
      "DIABETIC PROFILE - M"
    ],
    "testsIncludedHi": [
      "DIABETIC PROFILE - M"
    ],
    "description": "Comprehensive diagnostic profile for DIABETIC PROFILE - M conducted with clinical accuracy and 20% discount on standard MRP at Pawan Research Laboratory.",
    "descriptionHi": "पवन रिसर्च लैबोरेटरी में 20% एमआरपी छूट के साथ DIABETIC PROFILE - M का संपूर्ण नैदानिक हेल्थ पैकेज।",
    "sampleRequired": "Blood & Urine specimen as required by protocol",
    "recommendedFor": "Preventive healthcare & periodic screening",
    "mrp": 1400,
    "discountedPrice": 1120,
    "discountPercent": 20
  },
  {
    "id": "pkg-107",
    "name": "INFERTILITY PROFILE - A",
    "nameHi": "INFERTILITY PROFILE - A",
    "type": "wellness",
    "targetAudience": "Adults, families, seniors & individuals seeking preventive screening",
    "targetAudienceHi": "वयस्क, वरिष्ठ नागरिक एवं नियमित स्वास्थ्य परीक्षण चाहने वाले",
    "price": "₹3200",
    "isConfirmedPrice": true,
    "testsIncluded": [
      "INFERTILITY PROFILE - A"
    ],
    "testsIncludedHi": [
      "INFERTILITY PROFILE - A"
    ],
    "description": "Comprehensive diagnostic profile for INFERTILITY PROFILE - A conducted with clinical accuracy and 20% discount on standard MRP at Pawan Research Laboratory.",
    "descriptionHi": "पवन रिसर्च लैबोरेटरी में 20% एमआरपी छूट के साथ INFERTILITY PROFILE - A का संपूर्ण नैदानिक हेल्थ पैकेज।",
    "sampleRequired": "Blood & Urine specimen as required by protocol",
    "recommendedFor": "Preventive healthcare & periodic screening",
    "mrp": 4000,
    "discountedPrice": 3200,
    "discountPercent": 20
  },
  {
    "id": "pkg-108",
    "name": "INFERTILITY PROFILE-FEMALE",
    "nameHi": "INFERTILITY PROFILE-FEMALE",
    "type": "wellness",
    "targetAudience": "Adults, families, seniors & individuals seeking preventive screening",
    "targetAudienceHi": "वयस्क, वरिष्ठ नागरिक एवं नियमित स्वास्थ्य परीक्षण चाहने वाले",
    "price": "₹2800",
    "isConfirmedPrice": true,
    "testsIncluded": [
      "INFERTILITY PROFILE-FEMALE"
    ],
    "testsIncludedHi": [
      "INFERTILITY PROFILE-FEMALE"
    ],
    "description": "Comprehensive diagnostic profile for INFERTILITY PROFILE-FEMALE conducted with clinical accuracy and 20% discount on standard MRP at Pawan Research Laboratory.",
    "descriptionHi": "पवन रिसर्च लैबोरेटरी में 20% एमआरपी छूट के साथ INFERTILITY PROFILE-FEMALE का संपूर्ण नैदानिक हेल्थ पैकेज।",
    "sampleRequired": "Blood & Urine specimen as required by protocol",
    "recommendedFor": "Preventive healthcare & periodic screening",
    "mrp": 3500,
    "discountedPrice": 2800,
    "discountPercent": 20
  },
  {
    "id": "pkg-109",
    "name": "INFERTILITY PROFILE-MALE",
    "nameHi": "INFERTILITY PROFILE-MALE",
    "type": "wellness",
    "targetAudience": "Adults, families, seniors & individuals seeking preventive screening",
    "targetAudienceHi": "वयस्क, वरिष्ठ नागरिक एवं नियमित स्वास्थ्य परीक्षण चाहने वाले",
    "price": "₹2400",
    "isConfirmedPrice": true,
    "testsIncluded": [
      "INFERTILITY PROFILE-MALE"
    ],
    "testsIncludedHi": [
      "INFERTILITY PROFILE-MALE"
    ],
    "description": "Comprehensive diagnostic profile for INFERTILITY PROFILE-MALE conducted with clinical accuracy and 20% discount on standard MRP at Pawan Research Laboratory.",
    "descriptionHi": "पवन रिसर्च लैबोरेटरी में 20% एमआरपी छूट के साथ INFERTILITY PROFILE-MALE का संपूर्ण नैदानिक हेल्थ पैकेज।",
    "sampleRequired": "Blood & Urine specimen as required by protocol",
    "recommendedFor": "Preventive healthcare & periodic screening",
    "mrp": 3000,
    "discountedPrice": 2400,
    "discountPercent": 20
  },
  {
    "id": "pkg-110",
    "name": "GLUCOSE TOLERANCE TEST ( GTT) - 3 SAMPLES",
    "nameHi": "GLUCOSE TOLERANCE TEST ( GTT) - 3 SAMPLES",
    "type": "wellness",
    "targetAudience": "Adults, families, seniors & individuals seeking preventive screening",
    "targetAudienceHi": "वयस्क, वरिष्ठ नागरिक एवं नियमित स्वास्थ्य परीक्षण चाहने वाले",
    "price": "₹160",
    "isConfirmedPrice": true,
    "testsIncluded": [
      "GLUCOSE TOLERANCE TEST ( GTT) - 3 SAMPLES"
    ],
    "testsIncludedHi": [
      "GLUCOSE TOLERANCE TEST ( GTT) - 3 SAMPLES"
    ],
    "description": "Comprehensive diagnostic profile for GLUCOSE TOLERANCE TEST ( GTT) - 3 SAMPLES conducted with clinical accuracy and 20% discount on standard MRP at Pawan Research Laboratory.",
    "descriptionHi": "पवन रिसर्च लैबोरेटरी में 20% एमआरपी छूट के साथ GLUCOSE TOLERANCE TEST ( GTT) - 3 SAMPLES का संपूर्ण नैदानिक हेल्थ पैकेज।",
    "sampleRequired": "Blood & Urine specimen as required by protocol",
    "recommendedFor": "Preventive healthcare & periodic screening",
    "mrp": 200,
    "discountedPrice": 160,
    "discountPercent": 20
  },
  {
    "id": "pkg-111",
    "name": "GLUCOSE TOLERANCE TEST ( GTT) - 5 SAMPLES",
    "nameHi": "GLUCOSE TOLERANCE TEST ( GTT) - 5 SAMPLES",
    "type": "wellness",
    "targetAudience": "Adults, families, seniors & individuals seeking preventive screening",
    "targetAudienceHi": "वयस्क, वरिष्ठ नागरिक एवं नियमित स्वास्थ्य परीक्षण चाहने वाले",
    "price": "₹240",
    "isConfirmedPrice": true,
    "testsIncluded": [
      "GLUCOSE TOLERANCE TEST ( GTT) - 5 SAMPLES"
    ],
    "testsIncludedHi": [
      "GLUCOSE TOLERANCE TEST ( GTT) - 5 SAMPLES"
    ],
    "description": "Comprehensive diagnostic profile for GLUCOSE TOLERANCE TEST ( GTT) - 5 SAMPLES conducted with clinical accuracy and 20% discount on standard MRP at Pawan Research Laboratory.",
    "descriptionHi": "पवन रिसर्च लैबोरेटरी में 20% एमआरपी छूट के साथ GLUCOSE TOLERANCE TEST ( GTT) - 5 SAMPLES का संपूर्ण नैदानिक हेल्थ पैकेज।",
    "sampleRequired": "Blood & Urine specimen as required by protocol",
    "recommendedFor": "Preventive healthcare & periodic screening",
    "mrp": 300,
    "discountedPrice": 240,
    "discountPercent": 20
  },
  {
    "id": "pkg-112",
    "name": "HY FIT PACK -D",
    "nameHi": "HY FIT PACK -D",
    "type": "fitness",
    "targetAudience": "Athletes, gym enthusiasts, runners and active individuals",
    "targetAudienceHi": "जिम जाने वाले युवाओं, धावकों और फिटनेस उत्साही व्यक्तियों हेतु",
    "price": "₹2360",
    "isConfirmedPrice": true,
    "testsIncluded": [
      "HY FIT PACK -D"
    ],
    "testsIncludedHi": [
      "HY FIT PACK -D"
    ],
    "description": "Comprehensive diagnostic profile for HY FIT PACK -D conducted with clinical accuracy and 20% discount on standard MRP at Pawan Research Laboratory.",
    "descriptionHi": "पवन रिसर्च लैबोरेटरी में 20% एमआरपी छूट के साथ HY FIT PACK -D का संपूर्ण नैदानिक हेल्थ पैकेज।",
    "sampleRequired": "Blood & Urine specimen as required by protocol",
    "recommendedFor": "Preventive healthcare & periodic screening",
    "mrp": 2950,
    "discountedPrice": 2360,
    "discountPercent": 20
  },
  {
    "id": "pkg-113",
    "name": "HY FIT PACK -C",
    "nameHi": "HY FIT PACK -C",
    "type": "fitness",
    "targetAudience": "Athletes, gym enthusiasts, runners and active individuals",
    "targetAudienceHi": "जिम जाने वाले युवाओं, धावकों और फिटनेस उत्साही व्यक्तियों हेतु",
    "price": "₹1880",
    "isConfirmedPrice": true,
    "testsIncluded": [
      "HY FIT PACK -C"
    ],
    "testsIncludedHi": [
      "HY FIT PACK -C"
    ],
    "description": "Comprehensive diagnostic profile for HY FIT PACK -C conducted with clinical accuracy and 20% discount on standard MRP at Pawan Research Laboratory.",
    "descriptionHi": "पवन रिसर्च लैबोरेटरी में 20% एमआरपी छूट के साथ HY FIT PACK -C का संपूर्ण नैदानिक हेल्थ पैकेज।",
    "sampleRequired": "Blood & Urine specimen as required by protocol",
    "recommendedFor": "Preventive healthcare & periodic screening",
    "mrp": 2350,
    "discountedPrice": 1880,
    "discountPercent": 20
  },
  {
    "id": "pkg-114",
    "name": "ANC NEW RAPID",
    "nameHi": "ANC NEW RAPID",
    "type": "wellness",
    "targetAudience": "Adults, families, seniors & individuals seeking preventive screening",
    "targetAudienceHi": "वयस्क, वरिष्ठ नागरिक एवं नियमित स्वास्थ्य परीक्षण चाहने वाले",
    "price": "₹1344",
    "isConfirmedPrice": true,
    "testsIncluded": [
      "ANC NEW RAPID"
    ],
    "testsIncludedHi": [
      "ANC NEW RAPID"
    ],
    "description": "Comprehensive diagnostic profile for ANC NEW RAPID conducted with clinical accuracy and 20% discount on standard MRP at Pawan Research Laboratory.",
    "descriptionHi": "पवन रिसर्च लैबोरेटरी में 20% एमआरपी छूट के साथ ANC NEW RAPID का संपूर्ण नैदानिक हेल्थ पैकेज।",
    "sampleRequired": "Blood & Urine specimen as required by protocol",
    "recommendedFor": "Preventive healthcare & periodic screening",
    "mrp": 1680,
    "discountedPrice": 1344,
    "discountPercent": 20
  },
  {
    "id": "pkg-115",
    "name": "BASIC FEVER PANEL",
    "nameHi": "BASIC FEVER PANEL",
    "type": "wellness",
    "targetAudience": "Adults, families, seniors & individuals seeking preventive screening",
    "targetAudienceHi": "वयस्क, वरिष्ठ नागरिक एवं नियमित स्वास्थ्य परीक्षण चाहने वाले",
    "price": "₹560",
    "isConfirmedPrice": true,
    "testsIncluded": [
      "BASIC FEVER PANEL"
    ],
    "testsIncludedHi": [
      "BASIC FEVER PANEL"
    ],
    "description": "Comprehensive diagnostic profile for BASIC FEVER PANEL conducted with clinical accuracy and 20% discount on standard MRP at Pawan Research Laboratory.",
    "descriptionHi": "पवन रिसर्च लैबोरेटरी में 20% एमआरपी छूट के साथ BASIC FEVER PANEL का संपूर्ण नैदानिक हेल्थ पैकेज।",
    "sampleRequired": "Blood & Urine specimen as required by protocol",
    "recommendedFor": "Preventive healthcare & periodic screening",
    "mrp": 700,
    "discountedPrice": 560,
    "discountPercent": 20
  },
  {
    "id": "pkg-116",
    "name": "CBC GBP (PBS)",
    "nameHi": "CBC GBP (PBS)",
    "type": "wellness",
    "targetAudience": "Adults, families, seniors & individuals seeking preventive screening",
    "targetAudienceHi": "वयस्क, वरिष्ठ नागरिक एवं नियमित स्वास्थ्य परीक्षण चाहने वाले",
    "price": "₹480",
    "isConfirmedPrice": true,
    "testsIncluded": [
      "CBC GBP (PBS)"
    ],
    "testsIncludedHi": [
      "CBC GBP (PBS)"
    ],
    "description": "Comprehensive diagnostic profile for CBC GBP (PBS) conducted with clinical accuracy and 20% discount on standard MRP at Pawan Research Laboratory.",
    "descriptionHi": "पवन रिसर्च लैबोरेटरी में 20% एमआरपी छूट के साथ CBC GBP (PBS) का संपूर्ण नैदानिक हेल्थ पैकेज।",
    "sampleRequired": "Blood & Urine specimen as required by protocol",
    "recommendedFor": "Preventive healthcare & periodic screening",
    "mrp": 600,
    "discountedPrice": 480,
    "discountPercent": 20
  },
  {
    "id": "pkg-117",
    "name": "CAMP 1",
    "nameHi": "CAMP 1",
    "type": "wellness",
    "targetAudience": "Adults, families, seniors & individuals seeking preventive screening",
    "targetAudienceHi": "वयस्क, वरिष्ठ नागरिक एवं नियमित स्वास्थ्य परीक्षण चाहने वाले",
    "price": "₹2000",
    "isConfirmedPrice": true,
    "testsIncluded": [
      "CAMP 1"
    ],
    "testsIncludedHi": [
      "CAMP 1"
    ],
    "description": "Comprehensive diagnostic profile for CAMP 1 conducted with clinical accuracy and 20% discount on standard MRP at Pawan Research Laboratory.",
    "descriptionHi": "पवन रिसर्च लैबोरेटरी में 20% एमआरपी छूट के साथ CAMP 1 का संपूर्ण नैदानिक हेल्थ पैकेज।",
    "sampleRequired": "Blood & Urine specimen as required by protocol",
    "recommendedFor": "Preventive healthcare & periodic screening",
    "mrp": 2500,
    "discountedPrice": 2000,
    "discountPercent": 20
  },
  {
    "id": "pkg-118",
    "name": "PCOS",
    "nameHi": "PCOS",
    "type": "wellness",
    "targetAudience": "Adults, families, seniors & individuals seeking preventive screening",
    "targetAudienceHi": "वयस्क, वरिष्ठ नागरिक एवं नियमित स्वास्थ्य परीक्षण चाहने वाले",
    "price": "₹2520",
    "isConfirmedPrice": true,
    "testsIncluded": [
      "PCOS"
    ],
    "testsIncludedHi": [
      "PCOS"
    ],
    "description": "Comprehensive diagnostic profile for PCOS conducted with clinical accuracy and 20% discount on standard MRP at Pawan Research Laboratory.",
    "descriptionHi": "पवन रिसर्च लैबोरेटरी में 20% एमआरपी छूट के साथ PCOS का संपूर्ण नैदानिक हेल्थ पैकेज।",
    "sampleRequired": "Blood & Urine specimen as required by protocol",
    "recommendedFor": "Preventive healthcare & periodic screening",
    "mrp": 3150,
    "discountedPrice": 2520,
    "discountPercent": 20
  },
  {
    "id": "pkg-119",
    "name": "HY FIT PROFILE",
    "nameHi": "HY FIT PROFILE",
    "type": "fitness",
    "targetAudience": "Athletes, gym enthusiasts, runners and active individuals",
    "targetAudienceHi": "जिम जाने वाले युवाओं, धावकों और फिटनेस उत्साही व्यक्तियों हेतु",
    "price": "₹2800",
    "isConfirmedPrice": true,
    "testsIncluded": [
      "HY FIT PROFILE"
    ],
    "testsIncludedHi": [
      "HY FIT PROFILE"
    ],
    "description": "Comprehensive diagnostic profile for HY FIT PROFILE conducted with clinical accuracy and 20% discount on standard MRP at Pawan Research Laboratory.",
    "descriptionHi": "पवन रिसर्च लैबोरेटरी में 20% एमआरपी छूट के साथ HY FIT PROFILE का संपूर्ण नैदानिक हेल्थ पैकेज।",
    "sampleRequired": "Blood & Urine specimen as required by protocol",
    "recommendedFor": "Preventive healthcare & periodic screening",
    "mrp": 3500,
    "discountedPrice": 2800,
    "discountPercent": 20
  },
  {
    "id": "pkg-120",
    "name": "RA ASO CRP",
    "nameHi": "RA ASO CRP",
    "type": "wellness",
    "targetAudience": "Adults, families, seniors & individuals seeking preventive screening",
    "targetAudienceHi": "वयस्क, वरिष्ठ नागरिक एवं नियमित स्वास्थ्य परीक्षण चाहने वाले",
    "price": "₹1120",
    "isConfirmedPrice": true,
    "testsIncluded": [
      "RA ASO CRP"
    ],
    "testsIncludedHi": [
      "RA ASO CRP"
    ],
    "description": "Comprehensive diagnostic profile for RA ASO CRP conducted with clinical accuracy and 20% discount on standard MRP at Pawan Research Laboratory.",
    "descriptionHi": "पवन रिसर्च लैबोरेटरी में 20% एमआरपी छूट के साथ RA ASO CRP का संपूर्ण नैदानिक हेल्थ पैकेज।",
    "sampleRequired": "Blood & Urine specimen as required by protocol",
    "recommendedFor": "Preventive healthcare & periodic screening",
    "mrp": 1400,
    "discountedPrice": 1120,
    "discountPercent": 20
  },
  {
    "id": "pkg-121",
    "name": "BASIC FEVER PANEL - 2",
    "nameHi": "BASIC FEVER PANEL - 2",
    "type": "wellness",
    "targetAudience": "Adults, families, seniors & individuals seeking preventive screening",
    "targetAudienceHi": "वयस्क, वरिष्ठ नागरिक एवं नियमित स्वास्थ्य परीक्षण चाहने वाले",
    "price": "₹1120",
    "isConfirmedPrice": true,
    "testsIncluded": [
      "BASIC FEVER PANEL - 2"
    ],
    "testsIncludedHi": [
      "BASIC FEVER PANEL - 2"
    ],
    "description": "Comprehensive diagnostic profile for BASIC FEVER PANEL - 2 conducted with clinical accuracy and 20% discount on standard MRP at Pawan Research Laboratory.",
    "descriptionHi": "पवन रिसर्च लैबोरेटरी में 20% एमआरपी छूट के साथ BASIC FEVER PANEL - 2 का संपूर्ण नैदानिक हेल्थ पैकेज।",
    "sampleRequired": "Blood & Urine specimen as required by protocol",
    "recommendedFor": "Preventive healthcare & periodic screening",
    "mrp": 1400,
    "discountedPrice": 1120,
    "discountPercent": 20
  },
  {
    "id": "pkg-122",
    "name": "INDEPENDENT PROFILE",
    "nameHi": "INDEPENDENT PROFILE",
    "type": "wellness",
    "targetAudience": "Adults, families, seniors & individuals seeking preventive screening",
    "targetAudienceHi": "वयस्क, वरिष्ठ नागरिक एवं नियमित स्वास्थ्य परीक्षण चाहने वाले",
    "price": "₹2000",
    "isConfirmedPrice": true,
    "testsIncluded": [
      "INDEPENDENT PROFILE"
    ],
    "testsIncludedHi": [
      "INDEPENDENT PROFILE"
    ],
    "description": "Comprehensive diagnostic profile for INDEPENDENT PROFILE conducted with clinical accuracy and 20% discount on standard MRP at Pawan Research Laboratory.",
    "descriptionHi": "पवन रिसर्च लैबोरेटरी में 20% एमआरपी छूट के साथ INDEPENDENT PROFILE का संपूर्ण नैदानिक हेल्थ पैकेज।",
    "sampleRequired": "Blood & Urine specimen as required by protocol",
    "recommendedFor": "Preventive healthcare & periodic screening",
    "mrp": 2500,
    "discountedPrice": 2000,
    "discountPercent": 20
  }
];
